import {reorderedLayers} from './layer-order.js?v=20261022-3';
import {layerBounds,arrangeLayers} from './layout.js?v=20261022-3';
import {imagePresets,imageFilter,matchesImagePreset} from './image-adjustments.js?v=20261022-2';
import {openTextAssistant,replaceStyledRange} from './ai-assistant.js?v=20261023-1';
import {richSelection,setRichSelection,renderRichText,readRichText,insertRichText} from './rich-text.js?v=20261022-1';
const $ = (s, root = document) => root.querySelector(s);
const $$ = (s, root = document) => [...root.querySelectorAll(s)];
const iconPaths = {
  shapes:'<rect x="3" y="3" width="8" height="8" rx="2"/><circle cx="17" cy="7" r="4"/><path d="m7 14 5 7H2z"/><rect x="14" y="14" width="7" height="7" rx="1"/>',
  type:'<path d="M4 5V3h16v2M12 3v18M8 21h8"/>',image:'<rect x="3" y="3" width="18" height="18" rx="3"/><circle cx="8" cy="8" r="1.5"/><path d="m3 17 5-5 4 4 4-6 5 7"/>',
  layout:'<rect x="3" y="3" width="18" height="18" rx="3"/><path d="M3 9h18M10 9v12"/>',layers:'<path d="m12 3 10 6-10 6L2 9zM3 14l9 5 9-5M3 18l9 5 9-5"/>',help:'<circle cx="12" cy="12" r="9"/><path d="M9.5 9a2.5 2.5 0 0 1 5 .5c0 2-2.5 2-2.5 4M12 17h.01"/>',
  arrowUpRight:'<path d="M6 18 18 6M6 6h12v12"/>',undo:'<path d="m8 4-5 5 5 5M3 9h11a7 7 0 0 1 0 14"/>',redo:'<path d="m16 4 5 5-5 5m5-5H10a7 7 0 0 0 0 14"/>',
  cursor:'<path d="m4 3 16 9-8 2-3 7z"/>',hand:'<path d="M7 11V6a2 2 0 0 1 4 0v5-7a2 2 0 0 1 4 0v7-5a2 2 0 0 1 4 0v9c0 5-3 7-7 7-3 0-5-2-7-5l-3-4a2 2 0 0 1 3-2l2 2"/>',
  pen:'<path d="m4 20 1-5L17 3l4 4L9 19zM14 6l4 4M4 20l5-1"/>',frame:'<path d="M7 3v18M17 3v18M3 7h18M3 17h18"/>',chevronDown:'<path d="m7 10 5 5 5-5"/>',maximize:'<path d="M8 3H3v5m13-5h5v5M3 16v5h5m13-5v5h-5"/>',
  upload:'<path d="M12 16V3m-5 5 5-5 5 5M3 15v5h18v-5"/>',plus:'<path d="M12 5v14M5 12h14"/>',rect:'<rect x="4" y="5" width="16" height="14" rx="1"/>',roundrect:'<rect x="4" y="5" width="16" height="14" rx="5"/>',ellipse:'<circle cx="12" cy="12" r="8"/>',triangle:'<path d="m12 3 10 18H2z"/>',line:'<path d="M4 19 20 5"/>',arrow:'<path d="M3 17 21 7m-9-2 9 2-3 9"/>',star:'<path d="m12 2 3 7 7 1-5 5 1 7-6-4-6 4 1-7-5-5 7-1z"/>',heart:'<path d="M12 21 3 12a5.5 5.5 0 0 1 9-7 5.5 5.5 0 0 1 9 7z"/>',sparkles:'<path d="m12 3 2.5 6.5L21 12l-6.5 2.5L12 21l-2.5-6.5L3 12l6.5-2.5zM21 2v4m-2-2h4"/>',
  alignLeft:'<path d="M4 5h16M4 10h10M4 15h16M4 20h10"/>',alignCenter:'<path d="M4 5h16M7 10h10M4 15h16M7 20h10"/>',alignRight:'<path d="M4 5h16M10 10h10M4 15h16M10 20h10"/>',
  lock:'<rect x="5" y="10" width="14" height="11" rx="2"/><path d="M8 10V6a4 4 0 0 1 8 0v4M12 14v3"/>',unlock:'<rect x="5" y="10" width="14" height="11" rx="2"/><path d="M8 10V6a4 4 0 0 1 8 0M12 14v3"/>',
  eye:'<path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12"/><circle cx="12" cy="12" r="3"/>',eyeOff:'<path d="m3 3 18 18M10 5h2c6 0 10 7 10 7a24 24 0 0 1-4 4M6 6a21 21 0 0 0-4 6s4 7 10 7a13 13 0 0 0 5-1"/>',
  copy:'<rect x="8" y="8" width="13" height="13" rx="2"/><path d="M16 8V3H3v13h5"/>',trash:'<path d="M3 6h18M9 6V3h6v3M5 6l1 15h12l1-15M10 10v7m4-7v7"/>',rotate:'<path d="M4 10a8 8 0 1 1 2 8M4 4v6h6"/>',download:'<path d="M12 3v13m-5-5 5 5 5-5M3 17v4h18v-4"/>',folder:'<path d="M3 6V4h7l2 3h9v14H3z"/>',check:'<path d="m5 12 4 4L19 6"/>',x:'<path d="m6 6 12 12M6 18 18 6"/>',alignH:'<path d="M12 2v20M4 7h16v4H4zm3 7h10v4H7z"/>',alignV:'<path d="M2 12h20M7 4v16h4V4zm7 3v10h4V7z"/>',up:'<path d="m6 14 6-6 6 6"/>',down:'<path d="m6 10 6 6 6-6"/>',leaf:'<path d="M20 3C5 1 1 13 8 18c6 5 14-4 12-15ZM5 21l9-11"/>',flip:'<path d="M12 2v20M3 6v12l6-6zm18 0v12l-6-6z"/>',sun:'<circle cx="12" cy="12" r="4"/><path d="M12 2v2m0 16v2M2 12h2m16 0h2M5 5l1 1m12 12 1 1M5 19l1-1M18 6l1-1"/>',
};
iconPaths.alignTop='<path d="M3 4h18M7 8v12h4V8zm7 0v8h4V8z"/>';
iconPaths.alignBottom='<path d="M3 20h18M7 4v12h4V4zm7 4v8h4V8z"/>';
iconPaths.crop='<path d="M6 3v15h15M3 6h15v15M3 3l18 18"/>';
iconPaths.lineArrow=iconPaths.arrow;
iconPaths.arrow='<path d="M3 9h10V4l8 8-8 8v-5H3z"/>';
const icon = name => `<svg viewBox="0 0 24 24" aria-hidden="true">${iconPaths[name] || iconPaths.shapes}</svg>`;
const esc = s => String(s ?? '').replace(/[&<>"']/g, c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function hydrateIcons(root=document){$$('[data-icon]',root).forEach(el=>el.innerHTML=icon(el.dataset.icon));}
hydrateIcons();$('#undo').innerHTML=icon('undo');$('#redo').innerHTML=icon('redo');
const canvas=$('#artboard'), ctx=canvas.getContext('2d'), viewport=$('#viewport'), wrap=$('#artboardWrap');
// Retain the legacy storage key so existing browser projects stay available.
const STORAGE='shiguang-studio-project-v1';
const MAX_CANVAS_SIDE=16384,MAX_CANVAS_PIXELS=64*1000*1000;
const validCanvasSize=(w,h)=>Number.isInteger(w)&&Number.isInteger(h)&&w>=1&&h>=1&&w<=MAX_CANVAS_SIDE&&h<=MAX_CANVAS_SIDE&&w*h<=MAX_CANVAS_PIXELS;
const textLayouts=new WeakMap();
const uid=()=>crypto.randomUUID();
const clone=o=>structuredClone(o);
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const loadedFonts=new Set();
const fonts=[['Noto Local','思源黑体'],['Satoshi','Satoshi（西文）'],['DengXian','等线'],['Microsoft YaHei','微软雅黑'],['serif','衬线体 · 宋体'],['sans-serif','系统黑体'],['monospace','等宽字体']];
const baseLayer=(type,name,x,y,w,h)=>({id:uid(),type,name,x,y,w,h,rotation:0,opacity:1,visible:true,locked:false,fill:'#344c3e',stroke:'#344c3e',strokeWidth:0,shadow:0,radius:0});
function textLayer(text,x,y,w,size=32,extra={}){return {...baseLayer('text',text.replace(/\n/g,' '),x,y,w,size*1.5),text,autoWidth:true,fontFamily:'Noto Local',fontSize:size,bold:false,italic:false,underline:false,strike:false,lineHeight:1.4,letterSpacing:0,paragraphSpacing:0,align:'left',charStyles:{},...extra};}
function initialDocument(style='forest'){
 const dark=style==='ink',peach=style==='peach';const color=dark?'#eee9d7':peach?'#834a37':'#314b3d';
 const doc={version:1,name:peach?'日常的温度 · 生活海报':dark?'夜色漫游 · 灵感海报':'山野来信 · 灵感海报',width:800,height:1000,background:dark?'#243d3b':peach?'#f5dfcb':'#f3f0e5',fonts:[],layers:[]};
 const label=textLayer('THE OUTSIDE PROJECT',64,48,500,14,{fill:color,fontFamily:'Satoshi',letterSpacing:4});
 const number=textLayer('VOL. 001',616,49,120,13,{fill:color,fontFamily:'Satoshi',align:'right',letterSpacing:2});
 const title=textLayer(peach?'让日常\n有点温度。':dark?'在夜色里\n慢慢漫游。':'去山野，\n找回自己。',60,124,690,86,{fill:color,bold:true,lineHeight:1.19,letterSpacing:3,h:230});
 const caption=textLayer(peach?'COLLECT THE LITTLE THINGS':dark?'STAY A LITTLE LONGER':'LESS NOISE. MORE NATURE.',65,365,600,15,{fill:color,fontFamily:'Satoshi',letterSpacing:4});
 const image={...baseLayer('image','山野 · 风景',60,421,680,406),src:dark?'/images/wallhaven-wqery6-dark.webp':'/images/wallhaven-wqery6-light.webp',radius:170,topRound:true,brightness:100,contrast:100,saturation:peach?75:85,flipX:false,flipY:false,cropX:50,cropY:50};
 const circle={...baseLayer('shape','日光 · 圆形',637,329,98,98),shape:'ellipse',fill:'#dd805b'};
 const star={...baseLayer('shape','灵感 · 星芒',655,347,62,62),shape:'sparkle',fill:'#f9efdb',rotation:12};
 const foot=textLayer(peach?'把平凡，过成喜欢的模样。':dark?'给匆忙的世界，按下暂停。':'把日子，交还给自然。',63,865,650,28,{fill:color,letterSpacing:3});
 const rule={...baseLayer('shape','分隔线',64,931,672,1),shape:'line',fill:color,stroke:color,strokeWidth:1,opacity:.4};
 const bottom=textLayer('A LITTLE ESCAPE FROM THE EVERYDAY',64,952,600,10,{fill:color,fontFamily:'Satoshi',letterSpacing:2.4});
 const mark=textLayer('↗',693,935,40,32,{fill:color,fontFamily:'Satoshi',align:'right'});
 doc.layers=[label,number,title,caption,image,circle,star,foot,rule,bottom,mark];return doc;
}
let doc=initialDocument(),selectedId=doc.layers[2].id,activePanel='elements',tool='select',zoom=0.5,pan={x:0,y:0},drag=null,spaceHeld=false,clipboard=null;
let region=null,alignmentTarget='selection',layerSearch='';
let pendingTextKind=null;
let inlineEditBefore='',inlineHistory=[],inlineHistoryIndex=-1,inlineComposing=false;
const TEXT_STYLE_KEY='figlyph-text-style-v1';
const textStyleKeys=['fontFamily','fontSize','bold','italic','underline','strike','lineHeight','letterSpacing','paragraphSpacing','align','fill'];
function cleanTextStyle(source){const out={};if(!source||typeof source!=='object')return out;for(const k of textStyleKeys){const v=source[k];if(['bold','italic','underline','strike'].includes(k)?typeof v==='boolean':k==='fontFamily'?typeof v==='string'&&v.length<200&&!/["\\]/.test(v):k==='fill'?/^#[0-9a-f]{6}$/i.test(v):k==='align'?['left','center','right'].includes(v):Number.isFinite(v)&&(k==='fontSize'?v>=1&&v<=1000:k==='lineHeight'?v>0&&v<=5:Math.abs(v)<=1000))out[k]=v;}return out;}
let lastTextStyle={};try{lastTextStyle=cleanTextStyle(JSON.parse(localStorage.getItem(TEXT_STYLE_KEY)));}catch{}
function rememberTextStyle(l,overrides={}){if(l?.type!=='text')return;lastTextStyle=cleanTextStyle({...l,...overrides});try{localStorage.setItem(TEXT_STYLE_KEY,JSON.stringify(lastTextStyle));}catch{}}

let pendingShape=null,shapeColor='#000000';
let history=[],historyIndex=-1,saveTimer,toastTimer,editing=false,textRange=null;
let uploads=[];const imageCache=new Map(), imagePromises=new Map();
let selectedIds=new Set([selectedId]);
const selectedLayers=()=>doc.layers.filter(l=>selectedIds.has(l.id));
function setSelection(ids){selectedIds=new Set(ids.filter(id=>doc.layers.some(l=>l.id===id)));selectedId=[...selectedIds].at(-1)||null;}
const boundsOf=layerBounds;
function selectionBounds(){const all=selectedLayers().map(boundsOf);if(!all.length)return null;const x=Math.min(...all.map(b=>b.x)),y=Math.min(...all.map(b=>b.y));return{x,y,w:Math.max(...all.map(b=>b.x+b.w))-x,h:Math.max(...all.map(b=>b.y+b.h))-y,rotation:0,visible:true};}
const selected=()=>doc.layers.find(l=>l.id===selectedId);
function toast(message){$('#toast').textContent=message;$('#toast').classList.add('visible');clearTimeout(toastTimer);toastTimer=setTimeout(()=>$('#toast').classList.remove('visible'),2800);}
function persist(){clearTimeout(saveTimer);$('#savedState').innerHTML='<span class="status-dot"></span>保存中…';saveTimer=setTimeout(()=>{try{localStorage.setItem(STORAGE,JSON.stringify(doc));$('#savedState').innerHTML='<span class="status-dot"></span>已自动保存';}catch{$('#savedState').textContent='存储空间不足，请保存项目文件';}},350);}
function commit(){const snap=JSON.stringify({doc,selectedId,selectedIds:[...selectedIds]});if(history[historyIndex]===snap)return;history=history.slice(0,historyIndex+1);history.push(snap);if(history.length>60)history.shift();historyIndex=history.length-1;persist();updateHistory();}
function checkpointSelection(){if(historyIndex<0)return;const snapshot=JSON.parse(history[historyIndex]);snapshot.selectedId=selectedId;snapshot.selectedIds=[...selectedIds];history[historyIndex]=JSON.stringify(snapshot);}
function updateHistory(){$('#undo').disabled=historyIndex<=0;$('#redo').disabled=historyIndex>=history.length-1;}
function undo(){if(historyIndex<=0)return;const state=JSON.parse(history[--historyIndex]);doc=state.doc;setSelection(state.selectedIds||[state.selectedId]);textRange=null;refresh();persist();updateHistory();}
function redo(){if(historyIndex>=history.length-1)return;const state=JSON.parse(history[++historyIndex]);doc=state.doc;setSelection(state.selectedIds||[state.selectedId]);textRange=null;refresh();persist();updateHistory();}
function getImage(src){if(imageCache.has(src))return imageCache.get(src);if(!imagePromises.has(src)){const im=new Image();const promise=new Promise((resolve,reject)=>{im.onload=()=>{imageCache.set(src,im);render();resolve(im);};im.onerror=()=>{imagePromises.delete(src);reject(new Error('图片无法读取'));};});promise.catch(()=>{});imagePromises.set(src,promise);im.src=src;}return null;}
async function loadFonts(){for(const f of doc.fonts||[]){try{if(!loadedFonts.has(f.family)){const face=new FontFace(f.family,`url(${f.data})`);await face.load();document.fonts.add(face);loadedFonts.add(f.family);}}catch{toast('部分自定义字体无法读取');}}await document.fonts.ready;render();}
const fontStacks={serif:'"Songti SC", "SimSun", "Noto Serif CJK SC", serif','sans-serif':'sans-serif',monospace:'monospace',DengXian:'DengXian, "等线", "Microsoft YaHei", "Noto Local", sans-serif','Microsoft YaHei':'"Microsoft YaHei", "微软雅黑", "Noto Local", sans-serif'};
function fontString(layer,style={}){const s={...layer,...style};const family=fontStacks[s.fontFamily]||`"${s.fontFamily.replace(/["\\]/g,'')}", sans-serif`;return `${s.italic?'italic ':''}${s.bold?'700':'400'} ${s.fontSize}px ${family}`;}
// Use alphabetic glyph metrics for both layout and drawing. CSS "top" baselines
// vary between fonts and can place italic or accented ink outside the object.
function textLines(c,l){
 c.textBaseline='alphabetic';c.textAlign='left';
 const lines=[];let line={chars:[],cursor:0,left:0,right:0,ascent:0,descent:0,maxSize:l.fontSize};
 let index=0,minWidth=1;
 const finish=paragraph=>{line.paragraph=paragraph;line.width=Math.max(line.right,line.chars.length?line.cursor-l.letterSpacing:0)-line.left;line.height=Math.max(line.maxSize*l.lineHeight,line.ascent+line.descent,1);lines.push(line);line={chars:[],cursor:0,left:0,right:0,ascent:0,descent:0,maxSize:l.fontSize};};
 for(const ch of l.text){
  if(ch==='\n'){finish(true);index+=ch.length;continue;}
  const style=l.charStyles?.[index]||{},size=style.fontSize||l.fontSize;c.font=fontString(l,style);
  const m=c.measureText(ch),outline=Math.max(0,l.strokeWidth||0)/2;
  const left=-(m.actualBoundingBoxLeft||0)-outline,right=(m.actualBoundingBoxRight??m.width)+outline;
  let ascent=Math.max(0,m.actualBoundingBoxAscent??size*.8)+outline;if(style.strike??l.strike)ascent=Math.max(ascent,size*.3);
  let descent=Math.max(0,m.actualBoundingBoxDescent??size*.2)+outline;
  if(style.underline??l.underline)descent=Math.max(descent,size*.16+Math.max(1,size/23));
  const advance=Math.max(1,m.width+l.letterSpacing);
  minWidth=Math.max(minWidth,right-Math.min(0,left),m.width);
  const nextLeft=Math.min(line.left,line.cursor+left),nextRight=Math.max(line.right,line.cursor+right,line.cursor+m.width);
  if(line.chars.length&&nextRight-nextLeft>Math.max(l.autoWidth===true?100000:l.w,minWidth)+.001)finish(false);
  line.left=Math.min(line.left,line.cursor+left);line.right=Math.max(line.right,line.cursor+right);
  line.chars.push({ch,index,style,advance,width:m.width,x:line.cursor,size});line.cursor+=advance;
  line.ascent=Math.max(line.ascent,ascent);line.descent=Math.max(line.descent,descent);line.maxSize=Math.max(line.maxSize,size);index+=ch.length;
 }
 finish(false);
 // A single glyph must fit even when a text box is manually narrowed.
 if(l.autoWidth===true){const previous=l.w;l.w=Math.max(1,Math.min(100000,Math.ceil(Math.max(...lines.map(line=>line.width)))));if(l.align==='right')l.x+=previous-l.w;else if(l.align==='center')l.x+=(previous-l.w)/2;}else l.w=Math.max(l.w,minWidth);
 return lines;
}
function reflowText(l){const lines=textLines(ctx,l);l.h=Math.max(1,lines.reduce((h,line)=>h+line.height+(line.paragraph?l.paragraphSpacing:0),0));textLayouts.set(l,lines);return lines;}
function syncTextGeometryInputs(layer){if(layer?.type!=='text')return;for(const key of ['x','y','w','h']){const input=$(`[data-prop="${key}"]`,$('#inspector'));if(input&&input!==document.activeElement)input.value=Math.round(layer[key]*100)/100;}}
async function ensureLayerFont(l){try{await Promise.all([...new Set([{},...Object.values(l.charStyles||{})].map(style=>fontString(l,style)))].map(font=>document.fonts.load(font,l.text||'字Ag')));if(doc.layers.includes(l)){render();persist();if(selectedId===l.id)refreshTextInspector();}}catch{toast('字体加载失败，请重新选择或导入字体');}}
function drawText(c,l){
 const lines=textLayouts.get(l)||reflowText(l);c.textBaseline='alphabetic';c.textAlign='left';let y=0;
 for(const line of lines){
  const align=l.align==='center'?(l.w-line.width)/2:l.align==='right'?l.w-line.width:0;
  const offset=align-line.left,baseline=y+(line.height-line.ascent-line.descent)/2+line.ascent;
  for(const item of line.chars){const style={...l,...item.style},x=offset+item.x;c.font=fontString(l,item.style);c.fillStyle=style.fill;c.fillText(item.ch,x,baseline);
   if(l.strokeWidth>0){c.strokeStyle=l.stroke;c.lineWidth=l.strokeWidth;c.lineJoin='round';c.strokeText(item.ch,x,baseline);}
   const thickness=Math.max(1,style.fontSize/23),width=Math.max(1,item.width);
   if(style.underline)c.fillRect(x,baseline+style.fontSize*.12,width,thickness);
   if(style.strike)c.fillRect(x,baseline-style.fontSize*.3,width,thickness);
  }
  y+=line.height+(line.paragraph?l.paragraphSpacing:0);
 }
}
function shapePath(c,l){const w=l.w,h=l.h;c.beginPath();switch(l.shape){case 'ellipse':c.ellipse(w/2,h/2,w/2,h/2,0,0,Math.PI*2);break;case 'triangle':c.moveTo(w/2,0);c.lineTo(w,h);c.lineTo(0,h);c.closePath();break;case 'line':c.moveTo(0,h/2);c.lineTo(w,h/2);break;case 'lineArrow':{const head=Math.min(w*.3,h/2);c.moveTo(0,h/2);c.lineTo(w,h/2);c.moveTo(w-head,h/2-head);c.lineTo(w,h/2);c.lineTo(w-head,h/2+head);break;}case 'arrow':{const t=Math.min(h*.28,w*.1);c.moveTo(0,h*.5-t*.6);c.lineTo(w*.7,h*.5-t*.6);c.lineTo(w*.7,0);c.lineTo(w,h/2);c.lineTo(w*.7,h);c.lineTo(w*.7,h*.5+t*.6);c.lineTo(0,h*.5+t*.6);c.closePath();break;}case 'star':case 'sparkle':{const n=l.shape==='star'?5:4;for(let i=0;i<n*2;i++){const r=i%2?0.22:.5;const a=i*Math.PI/n-Math.PI/2;const x=w/2+Math.cos(a)*w*r,y=h/2+Math.sin(a)*h*r;i?c.lineTo(x,y):c.moveTo(x,y);}c.closePath();break;}case 'heart':c.moveTo(w/2,h);c.bezierCurveTo(-w*.45,h*.35,0,-h*.35,w/2,h*.22);c.bezierCurveTo(w,-h*.35,w*1.45,h*.35,w/2,h);break;default:c.roundRect(0,0,w,h,Math.min(l.radius||0,w/2,h/2));}}
function drawLayer(c,l){if(!l.visible)return;c.save();c.globalAlpha=l.opacity;c.translate(l.x+l.w/2,l.y+l.h/2);c.rotate(l.rotation*Math.PI/180);c.translate(-l.w/2,-l.h/2);if(l.shadow){c.shadowColor='#1d291d50';c.shadowBlur=l.shadow;c.shadowOffsetY=l.shadow/3;}if(l.type==='text'){drawText(c,l);}else if(l.type==='image'){const im=getImage(l.src);if(im){c.beginPath();const r=Math.min(l.radius,l.w/2,l.h/2);c.roundRect(0,0,l.w,l.h,l.topRound?[r,r,0,0]:r);c.clip();c.filter=imageFilter(l);const scale=Math.max(l.w/im.naturalWidth,l.h/im.naturalHeight);const sw=l.w/scale,sh=l.h/scale;const sx=(im.naturalWidth-sw)*(l.cropX??50)/100,sy=(im.naturalHeight-sh)*(l.cropY??50)/100;c.translate(l.flipX?l.w:0,l.flipY?l.h:0);c.scale(l.flipX?-1:1,l.flipY?-1:1);c.drawImage(im,sx,sy,sw,sh,0,0,l.w,l.h);}}else if(l.type==='path'){c.strokeStyle=l.fill;c.lineWidth=l.strokeWidth;c.lineCap='round';c.lineJoin='round';c.beginPath();l.points.forEach(([x,y],i)=>i?c.lineTo(x*l.w,y*l.h):c.moveTo(x*l.w,y*l.h));if(l.points.length===1){c.lineTo(l.points[0][0]*l.w+.01,l.points[0][1]*l.h+.01);}c.stroke();}else{shapePath(c,l);if(l.shape==='line'||l.shape==='lineArrow'){c.strokeStyle=l.stroke;c.lineWidth=Math.max(1,l.strokeWidth);c.lineCap='round';c.lineJoin='round';if(l.dashed)c.setLineDash([l.strokeWidth*3,l.strokeWidth*2]);c.stroke();}else{let fill=l.backgroundFill?doc.background:l.fill;if(l.gradient&&!l.backgroundFill){fill=c.createLinearGradient(0,0,l.w,l.h);fill.addColorStop(0,l.fill);fill.addColorStop(1,l.gradientColor||'#e8bda4');}if(l.fillEnabled!==false){c.fillStyle=fill;c.fill();}if(l.strokeWidth>0){c.strokeStyle=l.stroke;c.lineWidth=l.strokeWidth;if(l.dashed)c.setLineDash([l.strokeWidth*3,l.strokeWidth*2]);c.stroke();}}}c.restore();}
function paint(c,transparent=false){c.clearRect(0,0,doc.width,doc.height);if(!transparent){c.fillStyle=doc.background;c.fillRect(0,0,doc.width,doc.height);}for(const l of doc.layers){if(c===ctx&&editing&&l.type==='text'&&l.id===selectedId)continue;drawLayer(c,l);}}
function render(){updateRegionSelection();for(const l of doc.layers)if(l.type==='text')reflowText(l);if(canvas.width!==doc.width||canvas.height!==doc.height){canvas.width=doc.width;canvas.height=doc.height;}paint(ctx);updateSelection();updateTextRangeOverlay();$('#layerCount').textContent=`${doc.layers.length} 个图层`;$('#sizeLabel').textContent=`${doc.width} × ${doc.height} px`;}
function updateTextRangeOverlay(){
 const overlay=$('#textRangeOverlay'),l=selected();
 if(!textRange||editing||selectedIds.size!==1||l?.type!=='text'||!l.visible){overlay.style.display='none';overlay.replaceChildren();return;}
 overlay.style.cssText=`display:block;left:${l.x}px;top:${l.y}px;width:${l.w}px;height:${l.h}px;transform:rotate(${l.rotation}deg)`;
 const fragment=document.createDocumentFragment();let y=0;
 for(const line of textLayouts.get(l)||reflowText(l)){
  const offset=(l.align==='center'?(l.w-line.width)/2:l.align==='right'?l.w-line.width:0)-line.left;
  const chars=line.chars.filter(item=>item.index<textRange.end&&item.index+item.ch.length>textRange.start);
  if(chars.length){const first=chars[0],last=chars.at(-1),mark=document.createElement('span');mark.style.cssText=`left:${offset+first.x}px;top:${y}px;width:${last.x+last.advance-first.x}px;height:${line.height}px`;fragment.append(mark);}
  y+=line.height+(line.paragraph?l.paragraphSpacing:0);
 }
 overlay.replaceChildren(fragment);
}
function positionCanvas(){wrap.style.width=doc.width+'px';wrap.style.height=doc.height+'px';wrap.style.transform=`translate(${-doc.width*zoom/2+pan.x}px,${-doc.height*zoom/2+pan.y}px) scale(${zoom})`;$('#zoomValue').textContent=Math.round(zoom*100)+'%';updateSelection();updateRegionSelection();}
function fit(){const r=viewport.getBoundingClientRect();zoom=clamp(Math.min((r.width-(r.width<400?36:110))/doc.width,(r.height-100)/doc.height),.005,4);pan={x:0,y:0};positionCanvas();}
function changeZoom(factor){zoom=clamp(zoom*factor,.005,4);positionCanvas();}
function updateSelection(){const multi=selectedIds.size>1,l=multi?selectionBounds():selected(),box=$('#selectionBox');if(!l||!l.visible||editing||tool==='brush'||tool==='shape'||tool==='region'||tool==='crop'||tool==='textPlace'){box.style.display='none';return;}box.style.cssText=`display:block;left:${l.x}px;top:${l.y}px;width:${l.w}px;height:${l.h}px;transform:rotate(${l.rotation}deg);border-width:${1.2/zoom}px`;box.classList.toggle('locked',l.locked);$$('button',box).forEach(el=>{el.style.display=l.locked||multi||tool==='marquee'?'none':'';el.style.width=8/zoom+'px';el.style.height=8/zoom+'px';el.style.borderWidth=1.2/zoom+'px';});$('.rotation-stem',box).style.display=multi||tool==='marquee'?'none':'';$('.rotation-stem',box).style.height=22/zoom+'px';$('.rotation-stem',box).style.top=-22/zoom+'px';$('.rotate-handle',box).style.top=-27/zoom+'px';$('#selectionSize').textContent=multi?`已选中 ${selectedIds.size} 个元素`:`${Math.round(l.w)} × ${Math.round(l.h)}`;$('#selectionSize').style.fontSize=9/zoom+'px';$('#selectionSize').style.bottom=-25/zoom+'px';$('#selectionSize').style.padding=`${3/zoom}px ${7/zoom}px`;}
function select(id,additive=false){finishTextEdit();const ids=additive?new Set(selectedIds):new Set();if(id){if(additive&&ids.has(id))ids.delete(id);else ids.add(id);}setSelection([...ids]);checkpointSelection();textRange=null;render();renderInspector();if(activePanel==='layers')renderAssets();}
function addLayer(l){doc.layers.push(l);setSelection([l.id]);textRange=null;setTool('select');commit();refresh();$('#assetPanel').classList.remove('mobile-open');}
function addText(kind=null){select(null);pendingTextKind=kind;setTool('textPlace');$('#assetPanel').classList.remove('mobile-open');$('#drawingHint').textContent='单击画布确定文字位置 · Esc 取消';}
function finishTextPlacement(e){const current=drag;drag=null;try{viewport.releasePointerCapture(current.pointer);}catch{}if(e.type==='pointercancel')return;const size=current.kind==='heading'?64:current.kind==='subheading'?36:22;const content=current.kind==='heading'?'写下你的灵感':current.kind==='subheading'?'让美好，慢慢发生。':'在这里，记录你的故事。';const style={bold:true,...lastTextStyle,...(current.kind?{fontSize:size,bold:current.kind==='heading'}:{})};const actualSize=style.fontSize||64;const width=Math.max(actualSize*1.2,Math.min(doc.width*.7,doc.width-current.start.x));const l=textLayer(content,current.start.x,current.start.y,width,actualSize,style);addLayer(l);rememberTextStyle(l);ensureLayerFont(l);startTextEdit(l);}
const shapeNames={rect:'矩形',roundrect:'圆角矩形',ellipse:'圆形',triangle:'三角形',line:'直线',arrow:'块状箭头',lineArrow:'线条箭头',star:'五角星',heart:'爱心',sparkle:'星芒'};
function addShape(shape){select(null);pendingShape=shape;setTool('shape');renderAssets();$('#assetPanel').classList.remove('mobile-open');$('#drawingHint').textContent=`${shapeNames[shape]} · 在画布上拖动绘制，Shift 等比 / 限定角度，Esc 取消`;}
function cancelShapeDrawing(){if(drag?.type!=='shape')return;const current=drag;if(current.drawn)doc.layers=doc.layers.filter(l=>l.id!==current.draft.id);drag=null;setSelection(current.previous);try{viewport.releasePointerCapture(current.pointer);}catch{}render();persist();renderInspector();}
function updateShapeDrawing(point,shift){
 const start=drag.start,end={x:clamp(point.x,0,doc.width),y:clamp(point.y,0,doc.height)};
 let dx=end.x-start.x,dy=end.y-start.y;
 if(!drag.drawn&&Math.hypot(dx,dy)*zoom<3)return;
 const l=drag.draft,directional=l.shape==='line'||l.shape==='arrow'||l.shape==='lineArrow';
 if(directional){
  let angle=Math.atan2(dy,dx),length=Math.hypot(dx,dy);
  if(shift){angle=Math.round(angle/(Math.PI/4))*Math.PI/4;dx=Math.cos(angle)*length;dy=Math.sin(angle)*length;}
  const ex=clamp(start.x+dx,0,doc.width),ey=clamp(start.y+dy,0,doc.height);
  dx=ex-start.x;dy=ey-start.y;l.w=Math.max(1,Math.hypot(dx,dy));l.h=l.shape==='line'?2:clamp(l.w*.25,8,80);l.rotation=Math.atan2(dy,dx)*180/Math.PI;l.x=(start.x+ex)/2-l.w/2;l.y=(start.y+ey)/2-l.h/2;
 }else{
  if(shift){const sx=dx<0?-1:1,sy=dy<0?-1:1;const size=Math.min(Math.max(Math.abs(dx),Math.abs(dy)),sx>0?doc.width-start.x:start.x,sy>0?doc.height-start.y:start.y);dx=sx*size;dy=sy*size;}
  l.x=Math.min(start.x,start.x+dx);l.y=Math.min(start.y,start.y+dy);l.w=Math.max(1,Math.abs(dx));l.h=Math.max(1,Math.abs(dy));if(l.shape==='roundrect')l.radius=Math.min(32,l.w/5,l.h/5);
 }
 if(!drag.drawn){doc.layers.push(l);drag.drawn=true;setSelection([l.id]);}
 render();$('#drawingHint').textContent=`${shapeNames[l.shape]} · ${Math.round(l.w)} × ${Math.round(l.h)} px`;
}
function finishShapeDrawing(e){
 if(e.type==='pointercancel'){cancelShapeDrawing();return;}
 updateShapeDrawing(toCanvas(e),e.shiftKey);const drawn=drag.drawn,pointer=drag.pointer;drag=null;try{viewport.releasePointerCapture(pointer);}catch{}
 if(drawn){setTool('select');commit();refresh();}else{$('#drawingHint').textContent=`${shapeNames[pendingShape]} · 拖动绘制，点击不会添加图形`;}
}
function duplicate(){const copies=selectedLayers().filter(l=>!l.locked).map(l=>({...clone(l),id:uid(),x:l.x+20,y:l.y+20,locked:false,name:l.name+' 副本'}));if(!copies.length)return;doc.layers.push(...copies);setSelection(copies.map(l=>l.id));textRange=null;commit();refresh();toast(`已复制 ${copies.length} 个图层`);}
function remove(){const ids=new Set(selectedLayers().filter(l=>!l.locked).map(l=>l.id));if(!ids.size){if(selected())toast('请先解锁此图层');return;}doc.layers=doc.layers.filter(l=>!ids.has(l.id));setSelection([]);commit();refresh();}
function reorder(direction){const next=reorderedLayers(doc.layers,selectedIds,direction);if(next.every((layer,i)=>layer===doc.layers[i]))return;doc.layers=next;commit();render();renderAssets();}
function filterLayerRows(){const query=layerSearch.trim().toLocaleLowerCase();let count=0;$$('[data-layer]',$('#assetPanel')).forEach(row=>{const layer=doc.layers.find(item=>item.id===row.dataset.layer),show=!query||(layer.name+' '+(layer.text||'')).toLocaleLowerCase().includes(query);row.hidden=!show;if(show)count++;});const status=$('#layerSearchStatus');if(status)status.textContent=query?`找到 ${count} 个图层`:'';const empty=$('#layerSearchEmpty');if(empty)empty.hidden=count!==0;}
function backgroundSwatches(){return `<div class="background-swatches">${[['#ffffff','白色'],['#000000','黑色'],['#f3f0e5','米白'],['#e5c9a5','浅杏'],['#243d3b','墨绿']].map(([color,name])=>`<button data-background="${color}" class="background-swatch ${doc.background.toLowerCase()===color?'active':''}" aria-label="背景设为${name}" title="${name}" style="--swatch:${color}"><span>${doc.background.toLowerCase()===color?'✓':''}</span><small>${name}</small></button>`).join('')}</div>`;}
function updateRegionSelection(){if(region){region.x=clamp(region.x,0,doc.width);region.y=clamp(region.y,0,doc.height);region.w=Math.min(region.w,doc.width-region.x);region.h=Math.min(region.h,doc.height-region.y);if(region.w<=0||region.h<=0)region=null;}const el=$('#regionSelection');if(!el)return;if(!['region','crop'].includes(tool)||!region){el.style.display='none';return;}el.style.cssText=`display:block;left:${region.x}px;top:${region.y}px;width:${region.w}px;height:${region.h}px;border-width:${1/zoom}px`;$('#regionHint').textContent=`${region.w} × ${region.h} px · ${tool==='crop'?'按 Enter 裁切画布':'按 Delete 填充为背景色'}`;}
function updateRegion(point,square=false){const end={x:clamp(point.x,0,doc.width),y:clamp(point.y,0,doc.height)},start=drag.start;if(tool==='crop'&&square){const dx=end.x-start.x,dy=end.y-start.y,side=Math.round(Math.min(Math.max(Math.abs(dx),Math.abs(dy)),dx<0?start.x:doc.width-start.x,dy<0?start.y:doc.height-start.y));end.x=start.x+(dx<0?-1:1)*side;end.y=start.y+(dy<0?-1:1)*side;}const x=Math.round(Math.min(start.x,end.x)),y=Math.round(Math.min(start.y,end.y));const right=Math.round(Math.max(start.x,end.x)),bottom=Math.round(Math.max(start.y,end.y));region=right>x&&bottom>y?{x,y,w:right-x,h:bottom-y}:null;updateRegionSelection();}
function finishRegion(e){const current=drag;if(e.type==='pointercancel')region=current.previous;else updateRegion(toCanvas(e),e.shiftKey);drag=null;try{viewport.releasePointerCapture(current.pointer);}catch{}updateRegionSelection();renderInspector();}
function fillRegion(){if(!region){toast('请先在画布上拖动选择要清除的区域');return;}const r=region;doc.layers.push({...baseLayer('shape','区域填充',r.x,r.y,r.w,r.h),shape:'rect',fill:doc.background,fillEnabled:true,backgroundFill:true,strokeWidth:0});region=null;setSelection([]);commit();refresh();$('#regionHint').textContent='已填充为背景色 · 继续拖动选择区域，Esc 取消';toast('已用背景色填充选区，可撤销');}
const uploadCard=()=>`<button class="upload-card" data-action="upload"><span class="upload-icon">${icon('upload')}</span><strong>上传你的图片</strong><small>拖拽到画布，或点击上传</small><small>JPG / PNG / WebP · 最大 15 MB</small></button>`;
function renderAssets(){const panel=$('#assetPanel');const heading=(title,sub,extra='')=>`<div class="panel-heading"><h2>${title}</h2><span>${extra}</span></div><p class="panel-subtitle">${sub}</p>`;
 if(activePanel==='elements'){panel.innerHTML=heading('创作，从这里开始','让每一个小灵感，都有形状。')+uploadCard()+`<div class="section-heading">文字<span>表达你的想法</span></div><button class="add-text-button" data-action="add-text">${icon('type')}添加文字<span>+</span></button><div class="section-heading">基础图形<span>选择后拖动绘制</span></div><div class="shape-grid">${Object.entries(shapeNames).slice(0,7).map(([key,name])=>`<button class="shape-tile ${tool==='shape'&&pendingShape===key?'active':''}" data-shape="${key}" aria-pressed="${tool==='shape'&&pendingShape===key}">${icon(key)}<span>${name}</span></button>`).join('')}</div><div class="section-heading">画布背景<span>独立于图形颜色</span></div>${backgroundSwatches()}`;
 }else if(activePanel==='text'){panel.innerHTML=heading('文字的力量','给灵感，一个恰好的表达。')+`<button class="add-text-button" data-action="add-text">${icon('plus')}添加文字框<span>T</span></button><div class="section-heading">文字样式<span>选择后在画布点击</span></div><button class="text-preset heading" data-text="heading">添加大标题</button><button class="text-preset subheading" data-text="subheading">添加副标题</button><button class="text-preset body" data-text="body">添加一段正文，记录此刻的灵感。</button><div class="section-heading">你的字体<button class="mini-link" data-action="font">${icon('plus')}导入字体</button></div><p class="panel-subtitle">支持 TTF、OTF、WOFF 和 WOFF2。字体会随项目一起保存。</p><div class="asset-note">${icon('type')}双击文字框即可编辑。选中部分文字，可单独调整字重、字体与颜色。</div>`;
 }else if(activePanel==='images'){panel.innerHTML=heading('你的影像','把喜欢的瞬间，放进作品里。')+uploadCard()+`<div class="section-heading">最近上传<span>${uploads.length} 张</span></div><div class="upload-thumbnails">${uploads.map((src,i)=>`<button data-upload-index="${i}" title="再次添加图片"><img src="${esc(src)}" alt="已上传的图片 ${i+1}"></button>`).join('')}</div>${uploads.length?'':`<div class="empty-state">${icon('image')}<br>你的图片，会出现在这里。</div>`}`;
 }else{panel.innerHTML=heading('图层管理','让每个元素，都在对的位置。',`${doc.layers.length} 个图层`)+`<label class="layer-search"><input id="layerSearch" type="search" value="${esc(layerSearch)}" aria-label="搜索图层" placeholder="搜索图层名称或文字"><button data-action="layer-clear-search" aria-label="清除图层搜索" title="清除搜索">×</button></label><p class="font-hint" id="layerSearchStatus" role="status"></p><div class="layer-order"><button data-action="layer-up" title="前移一层">${icon('up')}前移</button><button data-action="layer-down" title="后移一层">${icon('down')}后移</button><button data-action="layer-front" title="置于最上方">置顶</button><button data-action="layer-back" title="置于最下方">置底</button></div><div class="layer-list">${[...doc.layers].reverse().map(l=>`<div class="layer-row ${selectedIds.has(l.id)?'active':''} ${!l.visible?'muted':''}" data-layer="${l.id}" role="button" tabindex="0" aria-label="选择图层 ${esc(l.name)}"><span class="layer-thumb" style="color:${esc(l.fill)}">${l.type==='image'?`<img src="${esc(l.src)}" alt="">`:icon(l.type==='text'?'type':l.type==='path'?'pen':l.shape)}</span><span class="layer-name">${esc(l.name)}</span><button data-layer-lock="${l.id}" title="${l.locked?'解锁':'锁定'}" aria-label="${l.locked?'解锁':'锁定'} ${esc(l.name)}">${icon(l.locked?'lock':'unlock')}</button><button data-layer-visibility="${l.id}" title="${l.visible?'隐藏':'显示'}" aria-label="${l.visible?'隐藏':'显示'} ${esc(l.name)}">${icon(l.visible?'eye':'eyeOff')}</button></div>`).join('')}</div><p id="layerSearchEmpty" class="empty-state" hidden>没有匹配的图层</p><div class="asset-note">${icon('layers')}列表顶部的图层位于画面最上方。Shift + 点击可多选，支持整体调整前后顺序。</div>`;}
 if(activePanel==='layers')filterLayerRows();
}
const nfield=(prop,label,value,min=-10000,max=10000,step=1)=>`<label class="field"><span>${label}</span><input type="number" data-prop="${prop}" aria-label="${prop==='x'?'横向位置':prop==='y'?'纵向位置':prop==='w'?'对象宽度':prop==='h'?'对象高度':label}" value="${Math.round(value*100)/100}" min="${min}" max="${max}" step="${step}"></label>`;
const colorField=(prop,value,label='颜色')=>`<div class="color-control"><input type="color" data-prop="${prop}" value="${value}" aria-label="${label}"><input type="text" data-hex="${prop}" value="${value.toUpperCase()}" aria-label="${label}十六进制" maxlength="7"><span>HEX</span></div>`;
const rangeField=(prop,value,min,max,label,suffix='')=>`<label class="property-label">${label}</label><div class="range-row"><input type="range" data-prop="${prop}" min="${min}" max="${max}" value="${value}" aria-label="${label}"><output>${value}${suffix}</output></div>`;
const section=(title,body,extra=icon('chevronDown'))=>`<section class="property-section"><div class="property-title">${title}${extra}</div>${body}</section>`;
async function applyImageLayout(mode){
 const image=selected(),currentDocument=doc;if(image?.type!=='image'||image.locked)return;
 try{const loaded=getImage(image.src)||await imagePromises.get(image.src);if(doc!==currentDocument||selected()!==image||image.locked)return;
 let w=loaded.naturalWidth,h=loaded.naturalHeight;if(mode==='image-contain'){const ratio=Math.min(doc.width/w,doc.height/h);w*=ratio;h*=ratio;}else if(mode==='image-cover'){w=doc.width;h=doc.height;}
 const next={x:(doc.width-w)/2,y:(doc.height-h)/2,w,h,rotation:0,cropX:50,cropY:50};
 if(Object.entries(next).every(([key,value])=>Math.abs(image[key]-value)<1e-7))return;
 Object.assign(image,next);commit();render();renderInspector();toast(mode==='image-cover'?'图片已铺满画布，可微调取景':mode==='image-contain'?'图片已完整放入画布':'已恢复图片原始尺寸');
 }catch{toast('图片尚未加载完成，请稍后重试');}
}
function alignmentControls(multi=false){
 const count=selectedLayers().filter(layer=>layer.visible&&!layer.locked).length;
 const choices=[['align-left','左对齐','alignLeft'],['align-center','水平居中','alignH'],['align-right','右对齐','alignRight'],['align-top','顶对齐','alignTop'],['align-middle','垂直居中','alignV'],['align-bottom','底对齐','alignBottom']];
 return (multi?`<label class="layout-target">对齐到<select id="alignmentTarget" aria-label="对齐参考"><option value="selection" ${alignmentTarget==='selection'?'selected':''}>所选元素</option><option value="canvas" ${alignmentTarget==='canvas'?'selected':''}>画布</option></select></label>`:'')+`<div class="layout-align" role="group" aria-label="对齐">${choices.map(([action,label,symbol])=>`<button data-action="${action}" title="${multi?'': '画布'}${label}" aria-label="${multi?'': '画布'}${label}" ${count?'':'disabled'}>${icon(symbol)}<span>${label}</span></button>`).join('')}</div>`+(multi?`<div class="layout-distribute"><button data-action="distribute-horizontal" ${count<3?'disabled':''}>水平等间距</button><button data-action="distribute-vertical" ${count<3?'disabled':''}>垂直等间距</button></div><p class="font-hint">等间距需选择至少 3 个可编辑元素；按旋转后的边界计算。锁定和隐藏的图层保持原位。</p>`:'');
}
function arrangeSelection(action){const changes=arrangeLayers(selectedLayers(),action,doc,selectedIds.size>1?alignmentTarget:'canvas');let changed=false;for(const change of changes){const layer=doc.layers.find(item=>item.id===change.id);for(const key of ['x','y'])if(change[key]!==undefined&&Math.abs(layer[key]-change[key])>1e-7){layer[key]=change[key];changed=true;}}if(changed){commit();render();renderInspector();if(activePanel==='layers')renderAssets();}}
function imagePresetControls(image){return `<div class="image-presets" role="group" aria-label="图片滤镜">${imagePresets.map(preset=>`<button class="image-preset" data-image-preset="${preset.id}" aria-pressed="${matchesImagePreset(image,preset)}" ${image.locked?'disabled':''}><span class="image-preset-preview"><img src="${esc(image.src)}" alt="" loading="lazy" style="filter:${imageFilter(preset)}"></span><span>${preset.name}</span></button>`).join('')}</div><p class="font-hint">一键应用后可继续微调。选择「原图」恢复亮度、对比度和饱和度。</p>`;}
function syncImagePresets(){const image=selected();if(image?.type!=='image')return;$$('[data-image-preset]',$('#inspector')).forEach(button=>{const preset=imagePresets.find(p=>p.id===button.dataset.imagePreset);button.setAttribute('aria-pressed',String(matchesImagePreset(image,preset)));});}
function applyImagePreset(id){const image=selected(),preset=imagePresets.find(p=>p.id===id);if(image?.type!=='image'||!preset)return;if(image.locked){toast('请先解锁此图层');return;}if(matchesImagePreset(image,preset))return;for(const key of ['brightness','contrast','saturation'])image[key]=preset[key];commit();render();renderInspector();const button=$(`[data-image-preset="${id}"]`,$('#inspector'));button?.focus({preventScroll:true});toast(preset.id==='original'?'已恢复原图色彩，可撤销':`已应用${preset.name}滤镜，可继续微调`);}
function renderRegionInspector(){
 const cropping=tool==='crop';
 $('#inspector').innerHTML=`<div class="inspector-header"><strong>${cropping?'裁切画布':'区域清除'}</strong><span>${cropping?'Enter 确认':'Delete 填充'}</span></div>${cropping?'':section('背景颜色',backgroundSwatches())}${section('区域选择',region?`<div class="field-grid">${['x','y','w','h'].map(key=>`<label class="field"><span>${key.toUpperCase()}</span><input type="number" data-region="${key}" min="${key==='w'||key==='h'?1:0}" value="${region[key]}" aria-label="选区${({x:'横坐标',y:'纵坐标',w:'宽度',h:'高度'})[key]}"></label>`).join('')}</div>`:`<p class="panel-subtitle">在画布上拖动，选择要${cropping?'保留':'填充'}的矩形区域。</p>`)}<div class="property-section"><button class="button primary" data-action="${cropping?'crop-region':'fill-region'}" ${region?'':'disabled'}>${cropping?'裁切画布 · Enter':'填充为背景色 · Delete'}</button>${cropping?'<button class="button outline" data-action="cancel-region" style="margin-top:10px">取消裁切</button>':''}<p class="panel-subtitle" style="margin:15px 0 0">${cropping?'保留框内画面，框外图层仍保存在项目中。支持撤销；按住 Shift 拖动可选正方形。':'框内区域将变为当前背景色，可撤销。Esc 取消区域选择。'}</p></div>`;
}
function cropCanvas(){
 if(tool!=='crop'||!region){toast('请先拖动选择裁切范围');return;}const rect={...region};
 if(doc.layers.some(layer=>Math.abs(layer.x-rect.x)>100000||Math.abs(layer.y-rect.y)>100000)){toast('框外图层超出坐标上限，请先移近画布');return;}
 if(rect.x===0&&rect.y===0&&rect.w===doc.width&&rect.h===doc.height){setTool('select');toast('裁切范围与当前画布一致');return;}
 for(const layer of doc.layers){layer.x-=rect.x;layer.y-=rect.y;}doc.width=rect.w;doc.height=rect.h;region=null;setTool('select');setSelection([]);commit();refresh();fit();toast(`画布已裁切为 ${rect.w} × ${rect.h} px，可撤销`);
}

function renderInspector(){if(tool==='region'||tool==='crop'){renderRegionInspector();return;}if(selectedIds.size>1){$('#inspector').innerHTML=`<div class="inspector-header"><strong>多选元素</strong><span>${selectedIds.size} 个元素</span></div><div class="property-section"><p>已选中 ${selectedIds.size} 个元素</p><p class="panel-subtitle">拖动任一选中元素可整体移动。Shift + 点击增减选择；方向键微调，Delete 删除。锁定或隐藏的图层不参与全选与框选。</p>${alignmentControls(true)}<div class="inspector-actions"><button data-action="duplicate">${icon('copy')}复制所选</button><button data-action="delete">${icon('trash')}删除所选</button></div><button class="button outline" data-action="deselect">取消选择</button></div>`;return;}const original=selected(),actual=original?.backgroundFill?{...original,fill:doc.background}:original,l=actual&&textRange&&actual.type==='text'?{...actual,...actual.charStyles?.[textRange.start]}:actual,panel=$('#inspector');if(!l){panel.innerHTML=`<div class="inspector-header"><strong>画布设置</strong><span>CANVAS</span></div>${section('画布尺寸',`<div class="field-grid"><label class="field"><span>W</span><input data-doc="width" type="number" min="1" max="16384" value="${doc.width}" aria-label="画布宽度"></label><label class="field"><span>H</span><input data-doc="height" type="number" min="1" max="16384" value="${doc.height}" aria-label="画布高度"></label></div>`)}${section('背景颜色',`${backgroundSwatches()}<div class="color-control" style="margin-top:12px"><input type="color" data-doc="background" value="${doc.background}" aria-label="画布背景色"><span>${doc.background.toUpperCase()}</span></div>`)}<div class="empty-state">${icon('cursor')}<br>选择一个元素<br>开始你的自由创作</div>`;return;}
 const kind=l.type==='text'?'文字':l.type==='image'?'图片':l.type==='path'?'画笔':'图形';
 let html=`<div class="inspector-header"><strong>${kind}属性</strong><span>${textRange?'局部样式':l.locked?'已锁定':'已选中 1 个元素'}</span></div>`;
 html+=section('图层名称',`<input id="layerName" class="layer-name-input" data-layer-name="${l.id}" value="${esc(l.name)}" maxlength="60" aria-label="图层名称" ${l.locked?'disabled':''}>`);
 html+=section('位置与尺寸',`<div class="field-grid">${nfield('x','X',l.x)}${nfield('y','Y',l.y)}${nfield('w','W',l.w,1,16384)}${nfield('h','H',l.h,1,16384)}</div><div class="field-grid" style="margin-top:8px">${nfield('rotation','↻',l.rotation,-360,360)}<button class="field" data-action="toggle-lock">${icon(l.locked?'lock':'unlock')}<span>${l.locked?'解锁图层':'锁定图层'}</span></button></div>${alignmentControls()}`);
 if(l.type==='text'){
 html+=section('文字排版',`<label class="check-row" style="margin-top:0;margin-bottom:12px"><input type="checkbox" data-prop="autoWidth" ${l.autoWidth===true?'checked':''}>随文字自动调整宽度</label><p class="font-hint">手动修改宽度或拖动缩放后，按设定宽度换行。</p><button class="ai-text-button" data-action="ai-text">${icon('sparkles')}AI 文案改写<span>↗</span></button><select data-prop="fontFamily" class="full-select" aria-label="字体">${fonts.concat((doc.fonts||[]).map(f=>[f.family,f.name])).map(([v,n])=>`<option value="${v}" ${l.fontFamily===v?'selected':''}>${esc(n)}</option>`).join('')}</select><div class="field-grid" style="margin-top:8px">${nfield('fontSize','字号',l.fontSize,6,500)}<label class="field"><select data-prop="align" aria-label="文字对齐"><option value="left" ${l.align==='left'?'selected':''}>左对齐</option><option value="center" ${l.align==='center'?'selected':''}>居中</option><option value="right" ${l.align==='right'?'selected':''}>右对齐</option></select></label></div><div class="style-buttons"><button class="${l.bold?'active':''}" data-toggle="bold" title="加粗" aria-label="加粗" aria-pressed="${l.bold}"><b>B</b></button><button class="${l.italic?'active':''}" data-toggle="italic" title="斜体" aria-label="斜体"><i>I</i></button><button class="${l.underline?'active':''}" data-toggle="underline" title="下划线" aria-label="下划线"><u>U</u></button><button class="${l.strike?'active':''}" data-toggle="strike" title="删除线" aria-label="删除线"><s>S</s></button></div><div class="field-grid">${nfield('lineHeight','行距',l.lineHeight,.6,5,.1)}${nfield('letterSpacing','字距',l.letterSpacing,-10,100,.5)}</div><div style="margin-top:8px">${nfield('paragraphSpacing','段距',l.paragraphSpacing,0,200)}</div><label class="property-label" data-text-range-status>${textRange?`已选中 ${textRange.end-textRange.start} 个字符 · 设置局部样式`:'文字颜色'}</label>${colorField('fill',l.fill,'文字颜色')}<p class="font-hint">等线、微软雅黑使用本机已安装字体；未安装时使用思源黑体。可导入自己的字体文件。</p><div class="property-label" style="display:flex;justify-content:space-between">文字内容<button class="mini-link" data-action="font">${icon('plus')}导入字体</button></div><textarea class="text-content" data-layer-id="${l.id}" data-prop="text" aria-label="文字内容" spellcheck="false">${esc(l.text)}</textarea><div style="font-size:9px;color:#a8af9e;margin-top:5px">选中部分文字，可单独修改样式</div>`);
 }else if(l.type==='image'){
 html+=section('图片布局',`<div class="image-layout-buttons"><button data-action="image-contain" ${l.locked?'disabled':''}>完整放入</button><button data-action="image-cover" ${l.locked?'disabled':''}>铺满画布</button><button data-action="image-original" ${l.locked?'disabled':''}>原始尺寸</button></div><p class="font-hint">保持图片比例并居中，重置旋转和取景；保留滤镜和翻转。</p>`);
 html+=section('图片滤镜',imagePresetControls(l));
 html+=section('图片调整',rangeField('brightness',l.brightness,0,200,'亮度','%')+rangeField('contrast',l.contrast,0,200,'对比度','%')+rangeField('saturation',l.saturation,0,200,'饱和度','%')+`<div class="style-buttons"><button data-action="flip-x" title="水平翻转">${icon('flip')} 水平翻转</button><button data-action="flip-y" title="垂直翻转">${icon('rotate')} 垂直翻转</button></div>`);
 html+=section('裁切与圆角',rangeField('cropX',l.cropX??50,0,100,'横向取景','%')+rangeField('cropY',l.cropY??50,0,100,'纵向取景','%')+rangeField('radius',l.radius,0,400,'圆角','px')+`<label class="check-row"><input type="checkbox" data-prop="topRound" ${l.topRound?'checked':''}>仅顶部圆角</label>`);
 }else{
 if(l.type==='path'){html+=section('画笔颜色',colorField('fill',l.fill,'画笔颜色'));}
 else if(l.shape!=='line'&&l.shape!=='lineArrow'){html+=section('填充',`<label class="check-row" style="margin-top:0"><input type="checkbox" data-prop="fillEnabled" ${l.fillEnabled!==false?'checked':''}>启用填充</label>`+(l.fillEnabled!==false?`<div style="margin-top:10px">${colorField('fill',l.fill,'填充颜色')}</div><label class="check-row"><input type="checkbox" data-prop="gradient" ${l.gradient?'checked':''}>渐变填充</label>${l.gradient?`<div style="margin-top:9px">${colorField('gradientColor',l.gradientColor||'#e8bda4','渐变终点颜色')}</div>`:''}`:'<p class="font-hint">空心图形，仅显示描边。</p>'));}
 if(l.type==='shape')html+=section('描边与圆角',colorField('stroke',l.stroke,'描边颜色')+rangeField('strokeWidth',l.strokeWidth,l.shape==='line'||l.shape==='lineArrow'?1:0,40,'描边粗细','px')+(l.shape==='rect'||l.shape==='roundrect'?rangeField('radius',l.radius,0,200,'圆角','px'):'')+`<label class="check-row"><input type="checkbox" data-prop="dashed" ${l.dashed?'checked':''}>虚线描边</label>`);
 else html+=section('画笔粗细',rangeField('strokeWidth',l.strokeWidth,1,100,'粗细','px'));
 }
 html+=section('外观',rangeField('opacity',Math.round(l.opacity*100),0,100,'不透明度','%')+rangeField('shadow',l.shadow,0,70,'阴影','px'));
 html+=`<div class="inspector-actions"><button data-action="duplicate">${icon('copy')}复制</button><button class="danger" data-action="delete">${icon('trash')}删除</button></div><div class="inspector-tip">${l.type==='text'?'双击文字框内任意位置，即可编辑':'拖动调整位置，拖动角点调整尺寸'}<br>Shift + 拖动角点 · 保持原始比例</div>`;
 panel.innerHTML=html;if(l.type==='text'){if(textRange){const content=$('.text-content',panel);content.setSelectionRange(textRange.start,textRange.end);}const heightInput=$('[data-prop="h"]',panel);heightInput.readOnly=true;heightInput.title='文字高度根据内容自动计算；拖动角点可等比缩放文字';}
}
// Update text settings in place: replacing a native picker or textarea on blur
// destroys its focus, pending click and native selection.
function refreshTextInspector(){
 const l=selected(),panel=$('#inspector'),content=$('.text-content',panel);
 if(l?.type!=='text'||selectedIds.size!==1||content?.dataset.layerId!==l.id){renderInspector();return;}
 const style={...l,...(textRange?l.charStyles?.[textRange.start]:{})};
 for(const el of $$('[data-prop]',panel)){
  const prop=el.dataset.prop;if(prop==='text')continue;
  const value=prop==='opacity'?Math.round(l.opacity*100):style[prop];
  if(value===undefined||el===document.activeElement)continue;
  if(el.type==='checkbox')el.checked=!!value;
  else el.value=el.type==='number'?Math.round(value*100)/100:value;
 }
 for(const el of $$('[data-toggle]',panel)){const enabled=!!style[el.dataset.toggle];el.classList.toggle('active',enabled);el.setAttribute('aria-pressed',String(enabled));}
 const hex=$('[data-hex="fill"]',panel);if(hex&&hex!==document.activeElement)hex.value=style.fill.toUpperCase();
 if(content.value!==l.text)content.value=l.text;
 if(textRange&&content!==document.activeElement)content.setSelectionRange(textRange.start,textRange.end);
 $('.inspector-header span',panel).textContent=textRange?'局部样式':l.locked?'已锁定':'已选中 1 个元素';
 $('[data-text-range-status]',panel).textContent=textRange?`已选中 ${textRange.end-textRange.start} 个字符 · 设置局部样式`:'文字颜色';
 updateTextRangeOverlay();
}
function refresh(){render();positionCanvas();renderAssets();renderInspector();$('#documentName').value=doc.name;updateHistory();}
function setTool(value){const previousTool=tool;if(drag?.type==='textPlace'){const pointer=drag.pointer;drag=null;try{viewport.releasePointerCapture(pointer);}catch{}}if(value!=='textPlace')pendingTextKind=null;viewport.classList.toggle('text-place-active',value==='textPlace');if(drag?.type==='region'){const pointer=drag.pointer;drag=null;try{viewport.releasePointerCapture(pointer);}catch{}}if(value!=='region'&&value!=='crop')region=null;viewport.classList.toggle('region-active',value==='region'||value==='crop');viewport.classList.toggle('crop-active',value==='crop');if(drag?.type==='shape')cancelShapeDrawing();finishTextEdit();tool=value;if(value!=='shape')pendingShape=null;viewport.classList.toggle('shape-active',value==='shape');$$('[data-shape]').forEach(el=>{const active=value==='shape'&&el.dataset.shape===pendingShape;el.classList.toggle('active',active);el.setAttribute('aria-pressed',String(active));});viewport.classList.toggle('marquee-active',value==='marquee');canvas.focus({preventScroll:true});['select','hand','brush','marquee','region','crop'].forEach(t=>$('#'+t+'Tool').classList.toggle('active',t===value));viewport.classList.toggle('pan-cursor',value==='hand');viewport.classList.toggle('brush-cursor',value==='brush');$('.toolbar-group').classList.toggle('brush-active',value==='brush');updateSelection();updateRegionSelection();if(['region','crop'].includes(value)||['region','crop'].includes(previousTool))renderInspector();}
function applyProperty(prop,value){const l=selected();if(!l)return;if(l.locked){toast('请先解锁此图层');renderInspector();return;}if(prop==='text'&&l.text===value)return;if(prop==='opacity')value=value/100;if(['fill','fillEnabled','gradient','gradientColor'].includes(prop)&&l.backgroundFill){l.fill=doc.background;delete l.backgroundFill;}
 if(l.type==='text'&&prop==='w')l.autoWidth=false;
 const previousText=l.text;const rich=['fill','fontSize','fontFamily','bold','italic','underline','strike'];
 if(l.type==='text'&&textRange&&rich.includes(prop)){for(let i=textRange.start;i<textRange.end;i++){l.charStyles[i]={...l.charStyles[i],[prop]:value};}}
 else{l[prop]=value;if(l.type==='text'&&rich.includes(prop)){for(const key of Object.keys(l.charStyles||{})){delete l.charStyles[key][prop];}}}
 if(prop==='text'){
  // Keep styles on unchanged text when a user inserts or deletes characters.
  let prefix=0,suffix=0;while(prefix<previousText.length&&prefix<value.length&&previousText[prefix]===value[prefix])prefix++;
  while(suffix<previousText.length-prefix&&suffix<value.length-prefix&&previousText[previousText.length-1-suffix]===value[value.length-1-suffix])suffix++;
  const styles={};for(const [key,style]of Object.entries(l.charStyles||{})){const i=Number(key);if(i<prefix)styles[i]=style;else if(i>=previousText.length-suffix)styles[i+value.length-previousText.length]=style;}l.charStyles=styles;
  textRange=null;if(!l.customName)l.name=value.replace(/\n/g,' ').slice(0,30)||'文字';
 }
 if(l.type==='image'&&['brightness','contrast','saturation'].includes(prop))syncImagePresets();
 if(l.type==='text'){reflowText(l);if(textStyleKeys.includes(prop))rememberTextStyle(l,textRange?l.charStyles?.[textRange.start]:{});}
 if(prop==='fontFamily')ensureLayerFont(l);render();syncTextGeometryInputs(l);
}
function numericValue(input){let n=Number(input.value);if(!Number.isFinite(n))return null;if(input.min!=='')n=Math.max(Number(input.min),n);if(input.max!=='')n=Math.min(Number(input.max),n);return n;}
$('#inspector').addEventListener('input',e=>{const el=e.target;const prop=el.dataset.prop;if(!prop||el.type==='checkbox'||el.tagName==='SELECT')return;const val=el.type==='number'||el.type==='range'?numericValue(el):el.value;if(val===null)return;applyProperty(prop,val);persist();if(el.type==='range')el.nextElementSibling.textContent=el.value+(prop==='opacity'||['brightness','contrast','saturation','cropX','cropY'].includes(prop)?'%':'px');if(el.type==='color'){const hex=el.parentElement.querySelector('[data-hex]');if(hex)hex.value=el.value.toUpperCase();}});
$('#inspector').addEventListener('change',e=>{const el=e.target;if(el.dataset.layerName){const layer=selected();if(!layer||layer.id!==el.dataset.layerName||layer.locked)return;const name=el.value.trim().slice(0,60);if(!name){el.value=layer.name;toast('请填写图层名称');return;}if(name!==layer.name){layer.name=name;layer.customName=true;commit();if(activePanel==='layers')renderAssets();}return;}if(el.id==='alignmentTarget'){alignmentTarget=el.value;return;}if(el.dataset.region&&region){const k=el.dataset.region;let value=Math.round(Number(el.value));if(!Number.isFinite(value))return;if(k==='x')region.x=clamp(value,0,doc.width-region.w);if(k==='y')region.y=clamp(value,0,doc.height-region.h);if(k==='w')region.w=clamp(value,1,doc.width-region.x);if(k==='h')region.h=clamp(value,1,doc.height-region.y);updateRegionSelection();renderInspector();return;}if(el.dataset.doc){const k=el.dataset.doc;const value=k==='background'?el.value:numericValue(el);if(k!=='background'&&!validCanvasSize(k==='width'?value:doc.width,k==='height'?value:doc.height)){toast('画布尺寸超过支持范围');renderInspector();return;}doc[k]=value;commit();render();positionCanvas();return;}if(el.dataset.hex){if(!/^#[0-9a-f]{6}$/i.test(el.value)){toast('请输入 # 开头的 6 位颜色代码');renderInspector();return;}applyProperty(el.dataset.hex,el.value);commit();refreshTextInspector();return;}if(!el.dataset.prop)return;if(el.dataset.prop==='text'&&!el.value.trim()){const l=selected();if(l?.type==='text'&&!l.locked)deleteEmptyTextFrame(l);else remove();return;}const val=el.type==='checkbox'?el.checked:el.type==='number'||el.type==='range'?numericValue(el):el.value;if(val===null)return;applyProperty(el.dataset.prop,val);commit();if(el.dataset.prop!=='text')refreshTextInspector();if(activePanel==='layers')renderAssets();});
function captureTextRange(e){const el=e.target;if(el===document.activeElement&&el.matches('.text-content,#inlineText')){const range=el.id==='inlineText'?richSelection(el):{start:el.selectionStart,end:el.selectionEnd};textRange=range&&range.end>range.start?range:null;refreshTextInspector();}}
document.addEventListener('selectionchange',()=>{if(editing&&!inlineComposing&&document.activeElement===$('#inlineText'))captureTextRange({target:$('#inlineText')});});
for(const type of ['select','mouseup','keyup']){document.addEventListener(type,captureTextRange,true);}
$('#inspector').addEventListener('pointerdown',()=>{captureTextRange({target:document.activeElement});if(editing){captureTextRange({target:$('#inlineText')});finishTextEdit({preserveRange:true,refreshInspector:false});}},true);
$('#inspector').addEventListener('click',e=>{const btn=e.target.closest('button');if(!btn)return;if(btn.dataset.imagePreset){applyImagePreset(btn.dataset.imagePreset);}else if(btn.dataset.toggle){const l=selected();if(!l)return;const prop=btn.dataset.toggle;let value=!l[prop];if(textRange){const first=l.charStyles?.[textRange.start];value=!(first?.[prop]??l[prop]);}applyProperty(prop,value);commit();refreshTextInspector();}else if(btn.dataset.action)handleAction(btn.dataset.action);});
$('#inspector').addEventListener('keydown',event=>{if(event.target.dataset.region&&event.key==='Enter'&&tool==='crop'){event.preventDefault();event.target.blur();cropCanvas();return;}if(!event.target.dataset.layerName)return;if(event.key==='Enter'){event.preventDefault();event.target.blur();}if(event.key==='Escape'){event.target.value=selected()?.name||'';event.target.blur();}});
$('#assetPanel').addEventListener('input',event=>{if(event.target.id==='layerSearch'){layerSearch=event.target.value;filterLayerRows();}});
$('#assetPanel').addEventListener('click',e=>{const el=e.target.closest('button,[data-layer]');if(!el)return;
 if(el.dataset.layerLock){const l=doc.layers.find(o=>o.id===el.dataset.layerLock);l.locked=!l.locked;commit();refresh();}
 else if(el.dataset.layerVisibility){const l=doc.layers.find(o=>o.id===el.dataset.layerVisibility);l.visible=!l.visible;commit();refresh();}
 else if(el.dataset.layer){select(el.dataset.layer,e.shiftKey);}
 else if(el.dataset.action)handleAction(el.dataset.action);
 else if(el.dataset.shape)addShape(el.dataset.shape);
 else if(el.dataset.text)addText(el.dataset.text);
 else if(el.dataset.uploadIndex!==undefined)addImage(uploads[Number(el.dataset.uploadIndex)]);
});
$('#assetPanel').addEventListener('keydown',e=>{if(e.key==='Enter'&&e.target.dataset.layer)select(e.target.dataset.layer,e.shiftKey);});
function handleAction(action){const l=selected();switch(action){case 'crop-region':cropCanvas();break;case 'cancel-region':setTool('select');select(null);break;case 'image-contain':case 'image-cover':case 'image-original':applyImageLayout(action);break;case 'ai-text':openAIText();break;case 'fill-region':fillRegion();break;case 'deselect':select(null);break;case 'upload':$('#imageInput').click();break;case 'font':$('#fontInput').click();break;case 'add-text':addText();break;case 'duplicate':duplicate();break;case 'delete':remove();break;case 'layer-clear-search':layerSearch='';$('#layerSearch').value='';filterLayerRows();$('#layerSearch').focus();break;case 'layer-up':reorder('up');break;case 'layer-down':reorder('down');break;case 'layer-front':reorder('front');break;case 'layer-back':reorder('back');break;case 'toggle-lock':if(l){l.locked=!l.locked;commit();refresh();}break;
 case 'align-left':case 'align-center':case 'align-right':case 'align-top':case 'align-middle':case 'align-bottom':case 'distribute-horizontal':case 'distribute-vertical':arrangeSelection(action);break;
 case 'flip-x':case 'flip-y':if(l&&!l.locked){l[action==='flip-x'?'flipX':'flipY']=!l[action==='flip-x'?'flipX':'flipY'];commit();render();}break;}}
document.addEventListener('click',e=>{const button=e.target.closest('[data-background]');if(!button)return;doc.background=button.dataset.background;commit();refresh();});
$$('[data-panel]').forEach(el=>el.addEventListener('click',()=>{const isSame=activePanel===el.dataset.panel;activePanel=el.dataset.panel;$$('[data-panel]').forEach(b=>b.classList.toggle('active',b===el));renderAssets();$('#inspector').classList.remove('mobile-open');if(window.innerWidth<=760)$('#assetPanel').classList.toggle('mobile-open',!isSame||!$('#assetPanel').classList.contains('mobile-open'));}));
function toCanvas(e){const r=canvas.getBoundingClientRect();return{x:(e.clientX-r.left)/zoom,y:(e.clientY-r.top)/zoom};}
function toLocal(p,l){const a=-l.rotation*Math.PI/180,dx=p.x-l.x-l.w/2,dy=p.y-l.y-l.h/2;return{x:dx*Math.cos(a)-dy*Math.sin(a)+l.w/2,y:dx*Math.sin(a)+dy*Math.cos(a)+l.h/2};}
function hitTest(p){for(const l of [...doc.layers].reverse()){if(!l.visible||l.locked)continue;const q=toLocal(p,l);if(q.x>=-3&&q.y>=-3&&q.x<=l.w+3&&q.y<=l.h+3){if(l.type==='shape'&&l.shape==='ellipse'){if(((q.x-l.w/2)/(l.w/2))**2+((q.y-l.h/2)/(l.h/2))**2>1)continue;}return l;}}return null;}
function brushLayer(points){const xs=points.map(p=>p.x),ys=points.map(p=>p.y);const x=Math.min(...xs),y=Math.min(...ys),w=Math.max(1,Math.max(...xs)-x),h=Math.max(1,Math.max(...ys)-y);return{x,y,w,h,points:points.map(p=>[(p.x-x)/w,(p.y-y)/h])};}
function beginMarquee(p,e){const previous=e.shiftKey?[...selectedIds]:[];select(null);if(previous.length)setSelection(previous);drag={type:'marquee',start:p,end:p,previous,pointer:e.pointerId};}
function updateMarquee(){const a=drag.start,b=drag.end;const rect={x:Math.min(a.x,b.x),y:Math.min(a.y,b.y),w:Math.abs(b.x-a.x),h:Math.abs(b.y-a.y)};const el=$('#marqueeSelection');el.style.cssText=`display:block;left:${rect.x}px;top:${rect.y}px;width:${rect.w}px;height:${rect.h}px;border-width:${1/zoom}px`;const enclosed=doc.layers.filter(l=>{if(!l.visible||l.locked)return false;const b=boundsOf(l);return $('#marqueeMode').value==='contain'?b.x>=rect.x&&b.y>=rect.y&&b.x+b.w<=rect.x+rect.w&&b.y+b.h<=rect.y+rect.h:b.x<=rect.x+rect.w&&b.y<=rect.y+rect.h&&b.x+b.w>=rect.x&&b.y+b.h>=rect.y;});setSelection([...drag.previous,...enclosed.map(l=>l.id)]);$('#marqueeHint').textContent=`已选中 ${selectedIds.size} 个元素 · Shift 追加选择`;render();}
function finishMarquee(){if(Math.hypot(drag.end.x-drag.start.x,drag.end.y-drag.start.y)<3){setSelection(drag.previous);}else updateMarquee();}
viewport.addEventListener('pointerdown',e=>{if(e.button!==0&&e.button!==1)return;if(e.target.closest('.canvas-ruler'))return;
 if(editing&&e.target.closest('#inlineText'))return;finishTextEdit();canvas.focus({preventScroll:true});const p=toCanvas(e);const handle=e.target.dataset.handle;
 if(tool==='hand'||spaceHeld||e.button===1){drag={type:'pan',start:{x:e.clientX,y:e.clientY},pan:{...pan},pointer:e.pointerId};}
 else if(tool==='textPlace'){if(p.x<0||p.y<0||p.x>=doc.width||p.y>=doc.height)return;drag={type:'textPlace',kind:pendingTextKind,start:{x:Math.round(p.x),y:Math.round(p.y)},pointer:e.pointerId};}
 else if(tool==='region'||tool==='crop'){drag={type:'region',start:{x:Math.round(clamp(p.x,0,doc.width)),y:Math.round(clamp(p.y,0,doc.height))},pointer:e.pointerId,previous:region?clone(region):null};region=null;setSelection([]);updateRegionSelection();}
 else if(tool==='shape'){if(p.x<0||p.y<0||p.x>doc.width||p.y>doc.height)return;drag={type:'shape',start:p,pointer:e.pointerId,previous:[...selectedIds],drawn:false,draft:{...baseLayer('shape',shapeNames[pendingShape],p.x,p.y,1,1),shape:pendingShape,fill:shapeColor,stroke:shapeColor,strokeWidth:2,fillEnabled:false}};}
 else if(tool==='marquee'){beginMarquee(p,e);}
 else if(handle&&selectedIds.size===1&&selected()&&!selected().locked){const l=selected();drag={type:handle==='rotate'?'rotate':'resize',handle,start:p,old:clone(l),pointer:e.pointerId};}
 else if(tool==='brush'&&e.target===canvas){if(p.x<0||p.y<0||p.x>doc.width||p.y>doc.height)return;const l={...baseLayer('path','自由画笔',p.x,p.y,1,1),points:[[0,0]],fill:$('#brushColor').value,strokeWidth:clamp(Number($('#brushWidth').value)||8,1,100)};doc.layers.push(l);setSelection([l.id]);drag={type:'brush',points:[p],pointer:e.pointerId};render();}
 else if(e.target===canvas||e.target===viewport||e.target===wrap){const hit=tool==='marquee'?null:hitTest(p);if(hit){if(e.shiftKey){select(hit.id,true);}else if(!selectedIds.has(hit.id)){select(hit.id);}if(selectedIds.has(hit.id)){drag={type:'move',start:p,old:clone(hit),originals:selectedLayers().filter(l=>!l.locked).map(clone),pointer:e.pointerId};}}else{beginMarquee(p,e);}}
 if(drag){viewport.setPointerCapture(e.pointerId);e.preventDefault();}
});
viewport.addEventListener('pointermove',e=>{if(!drag)return;const p=toCanvas(e),l=selected();if(drag.type==='pan'){pan.x=drag.pan.x+e.clientX-drag.start.x;pan.y=drag.pan.y+e.clientY-drag.start.y;positionCanvas();return;}if(drag.type==='region'){updateRegion(p,e.shiftKey);return;}if(drag.type==='shape'){updateShapeDrawing(p,e.shiftKey);return;}if(drag.type==='marquee'){drag.end=p;updateMarquee();return;}if(!l)return;
 if(drag.type==='move'&&drag.originals.length>1){const dx=p.x-drag.start.x,dy=p.y-drag.start.y;for(const old of drag.originals){const layer=doc.layers.find(l=>l.id===old.id);layer.x=Math.round(old.x+dx);layer.y=Math.round(old.y+dy);}}
 else if(drag.type==='move'){let x=drag.old.x+p.x-drag.start.x,y=drag.old.y+p.y-drag.start.y;const snap=7/zoom;if(Math.abs(x+l.w/2-doc.width/2)<snap)x=(doc.width-l.w)/2;if(Math.abs(y+l.h/2-doc.height/2)<snap)y=(doc.height-l.h)/2;l.x=Math.round(x);l.y=Math.round(y);}
 else if(drag.type==='resize'){const old=drag.old,local=toLocal(p,old);const sx=drag.handle.includes('e')?1:-1,sy=drag.handle.includes('s')?1:-1;let w=Math.max(16,sx*(local.x-(sx===1?0:old.w))),h=Math.max(16,sy*(local.y-(sy===1?0:old.h)));if(e.shiftKey||l.type==='text'){const ratio=old.w/old.h;if(w/h>ratio)h=w/ratio;else w=h*ratio;}if(l.type==='text'){const sizes=[old.fontSize,...Object.values(old.charStyles||{}).map(s=>s.fontSize||old.fontSize)];const scale=clamp(w/old.w,1/Math.min(...sizes),1000/Math.max(...sizes));w=old.w*scale;h=old.h*scale;}const dx=sx*(w-old.w)/2,dy=sy*(h-old.h)/2,a=old.rotation*Math.PI/180;l.w=w;l.h=h;if(l.type==='text')l.autoWidth=false;l.x=old.x+old.w/2+dx*Math.cos(a)-dy*Math.sin(a)-w/2;l.y=old.y+old.h/2+dx*Math.sin(a)+dy*Math.cos(a)-h/2;if(l.type==='text'){l.fontSize=clamp(old.fontSize*w/old.w,1,1000);l.letterSpacing=old.letterSpacing*w/old.w;l.paragraphSpacing=old.paragraphSpacing*w/old.w;for(const [i,style]of Object.entries(l.charStyles||{})){if(drag.old.charStyles?.[i]?.fontSize)style.fontSize=clamp(drag.old.charStyles[i].fontSize*w/old.w,1,1000);}}}
 else if(drag.type==='rotate'){const c={x:l.x+l.w/2,y:l.y+l.h/2};let angle=Math.atan2(p.y-c.y,p.x-c.x)*180/Math.PI+90;l.rotation=e.shiftKey?Math.round(angle/15)*15:Math.round(angle);}
 else if(drag.type==='brush'){const last=drag.points.at(-1);if(Math.hypot(p.x-last.x,p.y-last.y)>1.5){drag.points.push(p);Object.assign(l,brushLayer(drag.points));}}
 render();});
function finishDrag(e){if(!drag)return;if(drag.type==='textPlace'){finishTextPlacement(e);return;}if(drag.type==='region'){finishRegion(e);return;}if(drag.type==='shape'){finishShapeDrawing(e);return;}const wasMarquee=drag.type==='marquee',changed=drag.type!=='pan'&&!wasMarquee;if(wasMarquee){if(e.type==='pointercancel'){setSelection(drag.previous);}else{drag.end=toCanvas(e);finishMarquee();}}drag=null;if(wasMarquee)checkpointSelection();$('#marqueeSelection').style.display='none';try{viewport.releasePointerCapture(e.pointerId);}catch{}if(changed){if(selected()?.type==='text')rememberTextStyle(selected());commit();}if(changed||wasMarquee){render();renderInspector();if(activePanel==='layers')renderAssets();}}
viewport.addEventListener('pointerup',finishDrag);viewport.addEventListener('pointercancel',finishDrag);
viewport.addEventListener('dblclick',e=>{if(tool!=='select'||isTyping(e.target)||e.target.closest('[data-handle]'))return;const l=hitTest(toCanvas(e));if(l?.type==='text'){select(l.id);startTextEdit(l);}});
function openAIText(){
 finishTextEdit({preserveRange:true});
 const original=selectedIds.size===1&&selected()?.type==='text'&&!selected().locked?selected():null;
 const snapshot=original?clone(original):null,sourceDocument=doc;
 const range=original&&textRange?{start:clamp(textRange.start,0,original.text.length),end:clamp(textRange.end,0,original.text.length)}:{start:0,end:original?.text.length||0};
 const source=original?original.text.slice(range.start,range.end):'';
 const insertionStyle=original?Object.fromEntries(textStyleKeys.map(key=>[key,{...original,...original.charStyles?.[range.start]}[key]])):{...lastTextStyle};
 openTextAssistant({source,selectionLabel:original?(textRange?`选中 ${range.end-range.start} 个字符`:'整个文本框'):'自由输入',allowReplace:!!original,showModal,
  onReplace:result=>{const target=doc.layers.find(layer=>layer.id===snapshot?.id);if(doc!==sourceDocument||!target||target.locked||target.text!==snapshot.text||JSON.stringify(target.charStyles)!==JSON.stringify(snapshot.charStyles))throw Error('原文已改变，请关闭助手并重新选择文字后再应用。');textRange=replaceStyledRange(target,range.start,range.end,result);setSelection([target.id]);reflowText(target);commit();render();renderInspector();if(activePanel==='layers')renderAssets();toast('已应用到原文选区 · 可撤销');},
  onAdd:result=>{if(result.length>50000)throw Error('文字过长，请精简到 50000 字符以内。');const size=insertionStyle.fontSize||32,width=Math.max(size*1.2,Math.min(original?.w||doc.width*.7,doc.width));const l=textLayer(result,original?.x??doc.width*.15,original?original.y+original.h+20:doc.height*.2,width,size,insertionStyle);reflowText(l);l.x=clamp(l.x,0,Math.max(0,doc.width-l.w));l.y=clamp(l.y,0,Math.max(0,doc.height-l.h));addLayer(l);ensureLayerFont(l);toast('已新增文字图层 · 原稿已保留');}
 });
}
$('#aiTool').addEventListener('pointerdown',()=>{captureTextRange({target:document.activeElement});finishTextEdit({preserveRange:true});});
$('#aiTool').onclick=openAIText;
function resolveInlineFont(family,fallback){const first=value=>value.split(',')[0].trim().replace(/^['"]|['"]$/g,'');const name=first(family);for(const [key,stack]of Object.entries(fontStacks))if(first(stack)===name)return key;return name||fallback;}
function positionInlineText(l){const el=$('#inlineText');el.dataset.autoWidth=String(l.autoWidth===true);el.style.cssText=`display:block;left:${l.x}px;top:${l.y}px;width:${l.w}px;min-height:${Math.max(l.h,l.fontSize*2)}px;font:${fontString(l)};line-height:${l.lineHeight};letter-spacing:${l.letterSpacing}px;color:${l.fill};text-align:${l.align};opacity:${l.opacity};-webkit-text-stroke:${l.strokeWidth}px ${l.stroke};text-shadow:${l.shadow?`0 ${l.shadow/3}px ${l.shadow}px #1d291d50`:'none'};transform:rotate(${l.rotation}deg)`;}
function richStateKey(l){return JSON.stringify([l.text,Object.entries(l.charStyles).map(([i,style])=>[i,Object.entries(style).sort(([a],[b])=>a.localeCompare(b))])]);}
function inlineSnapshot(){const l=selected();return {text:l.text,charStyles:clone(l.charStyles),range:richSelection($('#inlineText'))||{start:0,end:0}};}
function recordInlineHistory(){const next=inlineSnapshot(),previous=inlineHistory[inlineHistoryIndex];if(previous&&richStateKey(previous)===richStateKey(next)){previous.range=next.range;return;}inlineHistory=inlineHistory.slice(0,inlineHistoryIndex+1);inlineHistory.push(next);if(inlineHistory.length>100)inlineHistory.shift();inlineHistoryIndex=inlineHistory.length-1;}
function syncInlineText(){if(!editing||inlineComposing)return;const l=selected(),el=$('#inlineText');if(l?.type!=='text')return;const range=richSelection(el),next=readRichText(el,l,resolveInlineFont),changed=richStateKey(l)!==richStateKey(next);if(l.text!==next.text&&!l.customName)l.name=next.text.replace(/\n/g,' ').slice(0,30)||'文字';Object.assign(l,next);reflowText(l);if(changed){renderRichText(el,l,fontString);if(range&&document.activeElement===el)setRichSelection(el,range.start,range.end);}positionInlineText(l);recordInlineHistory();captureTextRange({target:el});render();return range;}
function inlineUndo(redo=false){const next=inlineHistoryIndex+(redo?1:-1);if(next<0||next>=inlineHistory.length)return;inlineHistoryIndex=next;const saved=inlineHistory[next],l=selected(),el=$('#inlineText');l.text=saved.text;l.charStyles=clone(saved.charStyles);if(!l.customName)l.name=l.text.replace(/\n/g,' ').slice(0,30)||'文字';reflowText(l);renderRichText(el,l,fontString);positionInlineText(l);setRichSelection(el,saved.range.start,saved.range.end);captureTextRange({target:el});render();}
function startTextEdit(l){if(l.locked)return;editing=true;inlineComposing=false;inlineEditBefore=richStateKey(l);const el=$('#inlineText');renderRichText(el,l,fontString);positionInlineText(l);render();el.focus();setRichSelection(el,0,l.text.length);inlineHistory=[];inlineHistoryIndex=-1;recordInlineHistory();}
function deleteEmptyTextFrame(l){doc.layers=doc.layers.filter(layer=>layer.id!==l.id);setSelection([]);textRange=null;commit();render();renderInspector();if(activePanel==='layers')renderAssets();}
function finishTextEdit({preserveRange=false,refreshInspector=true}={}){if(!editing)return;inlineComposing=false;const bookmark=syncInlineText();const el=$('#inlineText'),l=selected(),selection=bookmark||richSelection(el),range=preserveRange&&selection?.end>selection?.start?selection:null;rememberTextStyle(l);editing=false;el.style.display='none';if(l?.type==='text'){if(!l.text.trim()){deleteEmptyTextFrame(l);return;}if(richStateKey(l)!==inlineEditBefore)commit();}textRange=range;render();if(refreshInspector)renderInspector();else refreshTextInspector();}
$('#inlineText').addEventListener('input',syncInlineText);
$('#inlineText').addEventListener('compositionstart',()=>{if(inlineHistory[inlineHistoryIndex])inlineHistory[inlineHistoryIndex].range=richSelection($('#inlineText'))||{start:0,end:0};inlineComposing=true;});
$('#inlineText').addEventListener('compositionupdate',()=>{requestAnimationFrame(()=>{const layer=selected(),input=$('#inlineText');if(editing&&inlineComposing&&layer?.autoWidth===true)input.style.width=Math.max(1,input.scrollWidth)+'px';});});
$('#inlineText').addEventListener('compositionend',()=>{inlineComposing=false;syncInlineText();});
$('#inlineText').addEventListener('beforeinput',e=>{if(inlineComposing||e.isComposing)return;if(inlineHistory[inlineHistoryIndex])inlineHistory[inlineHistoryIndex].range=richSelection($('#inlineText'))||{start:0,end:0};if(e.inputType==='historyUndo'||e.inputType==='historyRedo'){e.preventDefault();inlineUndo(e.inputType==='historyRedo');}});
$('#inlineText').addEventListener('paste',e=>{e.preventDefault();if(inlineHistory[inlineHistoryIndex])inlineHistory[inlineHistoryIndex].range=richSelection($('#inlineText'))||{start:0,end:0};const text=e.clipboardData.getData('text/plain');if(text)insertRichText($('#inlineText'),text);});
$('#inlineText').addEventListener('blur',e=>{const toInspector=$('#inspector').contains(e.relatedTarget),toProperties=e.relatedTarget===$('#propertiesToggle');finishTextEdit({preserveRange:toInspector||toProperties,refreshInspector:!toInspector});});
$('#inlineText').addEventListener('keydown',e=>{if(e.isComposing)return;const mod=e.ctrlKey||e.metaKey,key=e.key.toLowerCase();if(mod&&(key==='z'||key==='y')){e.preventDefault();inlineUndo(key==='y'||e.shiftKey);return;}if(e.key==='Escape'||(mod&&e.key==='Enter')){e.preventDefault();finishTextEdit();canvas.focus();}});
viewport.addEventListener('wheel',e=>{e.preventDefault();if(e.ctrlKey||e.metaKey)changeZoom(e.deltaY>0?.93:1.075);else{pan.x-=e.deltaX;pan.y-=e.deltaY;positionCanvas();}},{passive:false});
$('#propertiesToggle').onclick=()=>{$('#inspector').classList.toggle('mobile-open');$('#assetPanel').classList.remove('mobile-open');};
$('#marqueeMode').addEventListener('pointerdown',e=>e.stopPropagation());
$('#marqueeMode').onchange=()=>{canvas.focus({preventScroll:true});$('#marqueeHint').textContent=$('#marqueeMode').value==='contain'?'完全包含元素才选中 · Shift 追加选择':'选框触及元素即可选中 · Shift 追加选择';};
$('#cropTool').onclick=()=>{select(null);setTool('crop');renderInspector();$('#regionHint').textContent='拖动框选裁切范围 · Shift 正方形 · Enter 确认 · Esc 取消';$('#assetPanel').classList.remove('mobile-open');};
$('#regionTool').onclick=()=>{select(null);setTool('region');renderInspector();$('#assetPanel').classList.remove('mobile-open');};
$('#marqueeTool').onclick=()=>setTool('marquee');
$('#selectTool').onclick=()=>setTool('select');$('#handTool').onclick=()=>setTool('hand');$('#brushTool').onclick=()=>setTool('brush');$('#undo').onclick=undo;$('#redo').onclick=redo;$('#zoomOut').onclick=()=>changeZoom(1/1.15);$('#zoomIn').onclick=()=>changeZoom(1.15);$('#fitCanvas').onclick=fit;$('#zoomValue').onclick=fit;
$('#documentName').addEventListener('change',e=>{doc.name=e.target.value.trim()||'未命名作品';e.target.value=doc.name;commit();});
async function addImage(src,name='图片'){
 try{
  getImage(src);const im=imageCache.get(src)||await imagePromises.get(src),w=im.naturalWidth,h=im.naturalHeight;
  const empty=doc.layers.length===0,width=empty?w:Math.max(doc.width,w),height=empty?h:Math.max(doc.height,h);
  if(!validCanvasSize(width,height)){toast('原图尺寸超过画布上限（单边 16384 px，总面积 6400 万像素），请先裁小图片');return false;}
  const resized=doc.width!==width||doc.height!==height;doc.width=width;doc.height=height;
  addLayer({...baseLayer('image',name,(width-w)/2,(height-h)/2,w,h),src,brightness:100,contrast:100,saturation:100,cropX:50,cropY:50,flipX:false,flipY:false});
  if(resized)fit();return true;
 }catch{toast('图片读取失败，请尝试其他文件');return false;}
}
const readData=file=>new Promise((resolve,reject)=>{const reader=new FileReader();reader.onload=()=>resolve(reader.result);reader.onerror=reject;reader.readAsDataURL(file);});
async function importImages(files){let count=0;for(const file of files){if(!['image/png','image/jpeg','image/webp','image/gif'].includes(file.type)){toast('请上传 PNG、JPG、WebP 或 GIF 图片');continue;}if(file.size>15*1024*1024){toast('单张图片请小于 15 MB');continue;}try{const src=await readData(file);if(await addImage(src,file.name.replace(/\.[^.]+$/,''))){uploads.unshift(src);count++;}}catch{toast('图片读取失败');}}if(count){toast(`已添加 ${count} 张图片`);if(activePanel==='images')renderAssets();}}
$('#imageInput').addEventListener('change',async e=>{await importImages([...e.target.files]);e.target.value='';});
$('#fontInput').addEventListener('change',async e=>{const file=e.target.files[0];if(!file)return;try{if(file.size>20*1024*1024)throw new Error('字体文件请小于 20 MB');const data=await readData(file),family='Custom'+uid().replaceAll('-','');const face=new FontFace(family,`url(${data})`);await face.load();document.fonts.add(face);loadedFonts.add(family);doc.fonts.push({family,name:file.name.replace(/\.[^.]+$/,''),data});if(selected()?.type==='text')applyProperty('fontFamily',family);commit();renderInspector();toast('字体已导入，并保存在项目中');}catch(err){toast(err.message==='字体文件请小于 20 MB'?err.message:'无法读取字体，请使用有效的字体文件');}e.target.value='';});
let dragDepth=0;viewport.addEventListener('dragenter',e=>{e.preventDefault();dragDepth++;viewport.classList.add('dragging');});viewport.addEventListener('dragover',e=>e.preventDefault());viewport.addEventListener('dragleave',()=>{if(--dragDepth<=0)viewport.classList.remove('dragging');});viewport.addEventListener('drop',async e=>{e.preventDefault();dragDepth=0;viewport.classList.remove('dragging');await importImages([...e.dataTransfer.files]);});
const LAYER_CLIPBOARD_TYPE='application/x-figlyph-layers+json';
window.addEventListener('copy',event=>{
 if(isTyping(event.target)||$('#modal').open||!event.clipboardData)return;
 const layers=selectedLayers().filter(layer=>!layer.locked);if(!layers.length)return;
 const families=new Set(layers.flatMap(layer=>[layer.fontFamily,...Object.values(layer.charStyles||{}).map(style=>style.fontFamily)]));
 const payload={version:1,layers:clone(layers),fonts:clone(doc.fonts.filter(font=>families.has(font.family)))};
 try{event.clipboardData.setData(LAYER_CLIPBOARD_TYPE,JSON.stringify(payload));event.clipboardData.setData('text/plain',layers.map(layer=>layer.name).join('\n'));clipboard=payload;event.preventDefault();toast(`已复制 ${layers.length} 个图层`);}catch{toast('剪贴板暂不可用，请使用复制图层按钮');}
});
function pasteLayerPayload(payload){
 if(!payload||payload.version!==1||!Array.isArray(payload.layers)||!payload.layers.length||doc.layers.length+payload.layers.length>500||!validateDocument({version:1,name:'剪贴板',width:doc.width,height:doc.height,background:doc.background,layers:payload.layers,fonts:payload.fonts||[]})){toast('剪贴板中的图层无效或数量超过上限');return;}
 const fonts=clone(payload.fonts||[]),copies=clone(payload.layers),mapping=new Map();
 for(const font of fonts){const existing=doc.fonts.find(item=>item.family===font.family);if(existing&&existing.data!==font.data){const old=font.family;font.family='Custom'+uid().replaceAll('-','');mapping.set(old,font.family);}}
 const additions=fonts.filter(font=>!doc.fonts.some(item=>item.family===font.family));if(doc.fonts.length+additions.length>50){toast('项目字体数量超过上限，请先移除部分自定义字体');return;}
 for(const layer of copies){layer.id=uid();layer.x=clamp(layer.x+24,-100000,100000);layer.y=clamp(layer.y+24,-100000,100000);layer.locked=false;if(mapping.has(layer.fontFamily))layer.fontFamily=mapping.get(layer.fontFamily);for(const style of Object.values(layer.charStyles||{}))if(mapping.has(style.fontFamily))style.fontFamily=mapping.get(style.fontFamily);}
 doc.fonts.push(...additions);doc.layers.push(...copies);setSelection(copies.map(layer=>layer.id));textRange=null;setTool('select');commit();refresh();loadFonts();toast(`已粘贴 ${copies.length} 个图层`);
}
function pastePlainText(text){
 if(!text.trim())return;if(text.length>10000){toast('单次粘贴文字请不超过 10000 个字符');return;}if(doc.layers.length>=500){toast('项目图层数量已达上限');return;}
 const size=lastTextStyle.fontSize||32,layer=textLayer(text,doc.width*.15,doc.height*.2,Math.max(1,doc.width*.7),size,lastTextStyle);reflowText(layer);
 if(layer.h>100000){toast('文字高度过大，请分段粘贴');return;}layer.y=Math.max(0,Math.min(layer.y,doc.height-layer.h));addLayer(layer);ensureLayerFont(layer);toast('已将剪贴板文字添加为图层');
}
window.addEventListener('paste',event=>{
 if(isTyping(event.target)||$('#modal').open)return;
 const data=event.clipboardData;if(!data)return;const files=[...data.files];
 if(files.length){event.preventDefault();importImages(files);return;}
 const encoded=data.getData(LAYER_CLIPBOARD_TYPE);
 if(encoded){event.preventDefault();if(encoded.length>40*1024*1024){toast('剪贴板内容过大，请使用项目文件传递');return;}try{pasteLayerPayload(JSON.parse(encoded));}catch{toast('无法读取剪贴板中的图层');}return;}
 const text=data.getData('text/plain');if(text){event.preventDefault();pastePlainText(text);return;}
 if(!data.types.length&&clipboard){event.preventDefault();pasteLayerPayload(clipboard);}
});

function isTyping(el){return !!el?.closest('input,textarea,select,[contenteditable=true]');}
window.addEventListener('keydown',e=>{if($('#modal').open)return;const mod=e.ctrlKey||e.metaKey,key=e.key.toLowerCase();if(mod&&key==='s'){e.preventDefault();finishTextEdit();commit();saveProject();return;}if(mod&&key==='a'&&!isTyping(e.target)){e.preventDefault();finishTextEdit();setTool('select');setSelection(doc.layers.filter(l=>l.visible&&!l.locked).map(l=>l.id));checkpointSelection();textRange=null;render();renderInspector();if(activePanel==='layers')renderAssets();return;}if(isTyping(e.target))return;if(mod&&key==='z'){e.preventDefault();if(drag?.type==='shape'){cancelShapeDrawing();return;}e.shiftKey?redo():undo();return;}if(mod&&key==='y'){e.preventDefault();redo();return;}if(mod&&key==='s'){e.preventDefault();saveProject();return;}if(mod&&key==='d'){e.preventDefault();duplicate();return;}if(mod&&(e.code==='BracketLeft'||e.code==='BracketRight')){e.preventDefault();reorder(e.code==='BracketRight'?(e.shiftKey?'front':'up'):(e.shiftKey?'back':'down'));return;}if(mod&&(key==='c'||key==='v'))return;if(e.code==='Space'){e.preventDefault();spaceHeld=true;viewport.classList.add('pan-cursor');return;}if(key==='v')setTool('select');if(key==='h')setTool('hand');if(key==='m')setTool('marquee');if(key==='r'){$('#regionTool').click();}if(key==='c')$('#cropTool').click();if(key==='enter'&&tool==='crop'){e.preventDefault();cropCanvas();return;}if(key==='b')setTool('brush');if(key==='t')addText();if(key==='delete'||key==='backspace'){e.preventDefault();if(tool==='region'){fillRegion();return;}if(tool==='crop'){region=null;updateRegionSelection();renderInspector();return;}remove();}if(key==='escape'){setTool('select');select(null);$('#assetPanel').classList.remove('mobile-open');$('#inspector').classList.remove('mobile-open');}const l=selected();if(l&&!l.locked&&['ArrowLeft','ArrowRight','ArrowUp','ArrowDown'].includes(e.key)){e.preventDefault();const s=e.shiftKey?10:1;for(const layer of selectedLayers().filter(o=>!o.locked)){if(e.key==='ArrowLeft')layer.x-=s;if(e.key==='ArrowRight')layer.x+=s;if(e.key==='ArrowUp')layer.y-=s;if(e.key==='ArrowDown')layer.y+=s;}commit();render();renderInspector();}});
window.addEventListener('keyup',e=>{if(e.code==='Space'){spaceHeld=false;viewport.classList.toggle('pan-cursor',tool==='hand');}});window.addEventListener('blur',()=>{spaceHeld=false;viewport.classList.toggle('pan-cursor',tool==='hand');});
function showModal(title,body){finishTextEdit();$('#modalContent').innerHTML=`<div class="modal-head"><h2>${title}</h2><button id="closeModal" aria-label="关闭">×</button></div><div class="modal-body">${body}</div>`;$('#closeModal').onclick=()=>$('#modal').close();$('#modal').showModal();}
$('#modal').addEventListener('click',e=>{if(e.target===$('#modal')){const r=e.target.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)e.target.close();}});
function dimensionDialog(isNew){showModal(isNew?'一张新画布，无限种可能':'调整画布',`<p>${isNew?'先选一个舒服的尺寸，让灵感有地方发生。新建前可通过「文件」保存当前项目。':'调整画布尺寸不会缩放现有图层，你可以继续自由排版。'}</p><label class="property-label">常用尺寸</label><select id="sizePreset" class="full-select"><option value="custom">自定义尺寸</option><option value="800,1000">竖版海报 · 800 × 1000</option><option value="1080,1080">方形配图 · 1080 × 1080</option><option value="1920,1080">横版封面 · 1920 × 1080</option><option value="1080,1920">手机壁纸 · 1080 × 1920</option></select><div class="field-grid form-row"><label class="field"><span>宽</span><input id="newWidth" type="number" min="1" max="16384" value="${doc.width}" aria-label="新画布宽度"><span>px</span></label><label class="field"><span>高</span><input id="newHeight" type="number" min="1" max="16384" value="${doc.height}" aria-label="新画布高度"><span>px</span></label></div><label class="property-label">背景颜色</label><div class="color-control"><input id="newBackground" type="color" value="${isNew?'#ffffff':doc.background}" aria-label="新画布背景"><span>选择喜欢的底色</span><button id="modalWhite" class="white-background-button">白色</button><button id="modalBlack" class="white-background-button">黑色</button></div><button class="button primary" id="confirmCanvas">${isNew?'创建新画布':'应用更改'} ${icon('arrowUpRight')}</button>`);
 $('#modalWhite').onclick=()=>{$('#newBackground').value='#ffffff';};$('#modalBlack').onclick=()=>{$('#newBackground').value='#000000';};
 $('#sizePreset').onchange=e=>{if(e.target.value!=='custom'){const [w,h]=e.target.value.split(',');$('#newWidth').value=w;$('#newHeight').value=h;}};$('#confirmCanvas').onclick=()=>{const width=Number($('#newWidth').value),height=Number($('#newHeight').value);if(!validCanvasSize(width,height)){toast('宽高需为 1–16384 的整数，且总面积不超过 6400 万像素');return;}if(isNew){doc={version:1,name:'未命名作品',width:Math.round(width),height:Math.round(height),background:$('#newBackground').value,layers:[],fonts:clone(doc.fonts)};region=null;setTool('select');setSelection([]);}else{doc.width=Math.round(width);doc.height=Math.round(height);doc.background=$('#newBackground').value;}commit();refresh();fit();$('#modal').close();toast(isNew?'新画布已准备好':'画布已更新');};}
$('#newProject').onclick=()=>dimensionDialog(true);$('#canvasSettings').onclick=()=>dimensionDialog(false);
function download(blob,filename){const link=document.createElement('a');const url=URL.createObjectURL(blob);link.href=url;link.download=filename;document.body.append(link);link.click();link.remove();setTimeout(()=>URL.revokeObjectURL(url),10000);}
function safeName(){return doc.name.replace(/[<>:"/\\|?*]/g,'_').slice(0,80)||'图绎作品';}
function saveProject(){download(new Blob([JSON.stringify(doc)],{type:'application/json'}),safeName()+'.figlyph');toast('项目已保存 · 可保留所有图层继续编辑');}
$('#projectMenu').onclick=()=>{showModal('你的创作文件',`<p>作品只在当前浏览器自动保存。下载项目文件，可以备份并在其他设备继续编辑。</p><div class="file-options"><a href="/editor/downloads/figlyph.zip?v=20261023-1" download>下载编辑器压缩包 ↗</a><button id="saveProject">${icon('download')}保存项目文件 <span style="margin-left:auto;color:#aaa">⌘ / Ctrl S</span></button><button id="openProject">${icon('folder')}打开项目文件</button><button id="showCanvas">${icon('frame')}画布尺寸与背景</button></div>`);$('#saveProject').onclick=()=>{saveProject();$('#modal').close();};$('#openProject').onclick=()=>{$('#projectInput').click();};$('#showCanvas').onclick=()=>{$('#modal').close();select(null);dimensionDialog(false);};};
function validateDocument(d){if(!d||d.version!==1||!validCanvasSize(d.width,d.height)||!/^#[0-9a-f]{6}$/i.test(d.background)||!Array.isArray(d.layers)||d.layers.length>500||!Array.isArray(d.fonts)||d.fonts.length>50||typeof d.name!=='string')return false;
 const ids=new Set();for(const l of d.layers){if(!l||typeof l.id!=='string'||ids.has(l.id)||!['text','shape','image','path'].includes(l.type)||typeof l.name!=='string')return false;ids.add(l.id);if(l.customName!==undefined&&typeof l.customName!=='boolean')return false;for(const p of ['x','y','w','h','rotation','opacity','shadow','radius','strokeWidth'])if(!Number.isFinite(l[p])||Math.abs(l[p])>100000)return false;if(l.w<=0||l.h<=0||l.opacity<0||l.opacity>1||typeof l.visible!=='boolean'||typeof l.locked!=='boolean'||!/^#[0-9a-f]{6}$/i.test(l.fill)||!/^#[0-9a-f]{6}$/i.test(l.stroke))return false;
 if(l.type==='text'){if(l.autoWidth!==undefined&&typeof l.autoWidth!=='boolean')return false;if(typeof l.text!=='string'||l.text.length>50000||typeof l.fontFamily!=='string'||/["\\]/.test(l.fontFamily)||!l.charStyles||typeof l.charStyles!=='object')return false;for(const p of ['fontSize','lineHeight','letterSpacing','paragraphSpacing'])if(!Number.isFinite(l[p]))return false;if(l.fontSize<1||l.fontSize>1000||l.lineHeight<=0||!['left','center','right'].includes(l.align))return false;for(const style of Object.values(l.charStyles)){if(!style||typeof style!=='object')return false;for(const key of Object.keys(style)){if(!['fontSize','fontFamily','fill','bold','italic','underline','strike'].includes(key))return false;if(key==='fontSize'&&(!Number.isFinite(style[key])||style[key]<1||style[key]>1000))return false;if(key==='fill'&&!/^#[0-9a-f]{6}$/i.test(style[key]))return false;if(key==='fontFamily'&&(typeof style[key]!=='string'||/["\\]/.test(style[key])))return false;}}}
 if(l.backgroundFill!==undefined&&(typeof l.backgroundFill!=='boolean'||l.type!=='shape'||l.shape!=='rect'||l.fillEnabled===false))return false;
 if(l.fillEnabled!==undefined&&typeof l.fillEnabled!=='boolean')return false;
 if(l.gradientColor&&!/^#[0-9a-f]{6}$/i.test(l.gradientColor))return false;
 if(l.type==='shape'&&!Object.keys(shapeNames).concat('sparkle').includes(l.shape))return false;
 if(l.type==='image'){if(typeof l.src!=='string'||!(/^(data:image\/(png|jpeg|webp|gif);base64,|\/images\/[a-z0-9_.-]+$)/i.test(l.src)))return false;for(const p of ['brightness','contrast','saturation','cropX','cropY'])if(!Number.isFinite(l[p])||l[p]<0||l[p]>200)return false;}
 if(l.type==='path'&&(!Array.isArray(l.points)||l.points.length>100000||!l.points.every(p=>Array.isArray(p)&&p.length===2&&p.every(Number.isFinite))))return false;
 }return d.fonts.every(f=>f&&typeof f.family==='string'&&/^Custom[a-z0-9]+$/i.test(f.family)&&typeof f.name==='string'&&typeof f.data==='string'&&/^data:(font\/[^;,]+|application\/[^;,]+|);base64,/i.test(f.data));}
$('#projectInput').addEventListener('change',async e=>{const file=e.target.files[0];if(!file)return;try{if(file.size>80*1024*1024)throw new Error();const data=JSON.parse(await file.text());if(!validateDocument(data))throw new Error();doc=data;region=null;setTool('select');setSelection([]);textRange=null;await loadFonts();commit();refresh();fit();$('#modal').close();toast('项目已打开，继续你的创作');}catch{toast('无法打开：请选择有效的图绎项目文件');}e.target.value='';});
function selectedExportArea(){
 const layers=selectedLayers().filter(layer=>layer.visible);if(!layers.length)return null;
 const boxes=layers.map(layer=>{const box=boundsOf(layer),padding=Math.ceil((layer.type==='shape'?layer.strokeWidth*Math.SQRT2/2:0)+(layer.shadow||0)*2.5);return {x:box.x-padding,y:box.y-padding,w:box.w+padding*2,h:box.h+padding*2};});
 const x=Math.floor(Math.min(...boxes.map(box=>box.x))),y=Math.floor(Math.min(...boxes.map(box=>box.y)));
 return {x,y,w:Math.ceil(Math.max(...boxes.map(box=>box.x+box.w)))-x,h:Math.ceil(Math.max(...boxes.map(box=>box.y+box.h)))-y,layers};
}
function openExportDialog(){
 finishTextEdit();let format='png';const selection=selectedExportArea();
 showModal('让作品，走出画布',`<p>选择导出范围，保留你想分享的部分。</p><label class="property-label">导出范围</label><select id="exportArea" class="full-select" aria-label="导出范围"><option value="canvas">整个画布</option><option value="selection" ${selection?'':'disabled'}>所选图层${selection?` · ${selection.layers.length} 个`:''}</option></select><div class="format-options"><button class="active" data-format="png">PNG</button><button data-format="jpeg">JPG</button><button data-format="webp">WebP</button></div><label class="property-label">导出尺寸</label><select id="exportScale" class="full-select" aria-label="导出尺寸"></select><p class="font-hint" id="exportDimensions" role="status"></p><label class="check-row" id="transparentRow"><input type="checkbox" id="transparentExport">透明背景</label><label class="property-label">图片质量</label><div class="range-row"><input type="range" id="exportQuality" min="20" max="100" value="95" aria-label="导出质量"><output>95%</output></div><button class="button primary" id="downloadImage">${icon('download')}下载图片</button><p class="font-hint" style="text-align:center">导出不包含编辑边框与辅助线；JPG 使用画布背景色。</p>`);
 const area=()=>$('#exportArea').value==='selection'?selection:{x:0,y:0,w:doc.width,h:doc.height,layers:doc.layers.filter(layer=>layer.visible)};
 const size=(region,scale)=>({width:Math.max(1,Math.round(region.w*scale)),height:Math.max(1,Math.round(region.h*scale))});
 const updateSizes=()=>{const region=area(),previous=$('#exportScale').value||'1';$('#exportScale').innerHTML=[['1','原始尺寸'],['2','2 倍清晰'],['0.5','轻量尺寸']].map(([value,label])=>{const {width,height}=size(region,Number(value));return `<option value="${value}" ${validCanvasSize(width,height)?'':'disabled'}>${label} · ${width} × ${height} px</option>`;}).join('');const options=[...$('#exportScale').options],chosen=options.find(option=>option.value===previous&&!option.disabled)||options.find(option=>!option.disabled);if(chosen)$('#exportScale').value=chosen.value;$('#downloadImage').disabled=!chosen;$('#exportDimensions').textContent=chosen?'每个方向最多 16384 px，总面积不超过 6400 万像素。':'范围超过导出上限，请缩小所选图层之间的距离或减少选择。';};
 $('#exportArea').onchange=updateSizes;updateSizes();
 $$('[data-format]',$('#modal')).forEach(button=>button.onclick=()=>{format=button.dataset.format;$$('[data-format]',$('#modal')).forEach(other=>other.classList.toggle('active',other===button));$('#transparentRow').style.display=format==='jpeg'?'none':'';});
 $('#exportQuality').oninput=e=>e.target.nextElementSibling.textContent=e.target.value+'%';
 $('#downloadImage').onclick=async()=>{
  const button=$('#downloadImage'),region=area(),scale=Number($('#exportScale').value),{width,height}=size(region,scale),transparent=format!=='jpeg'&&$('#transparentExport').checked,quality=Number($('#exportQuality').value)/100,currentDocument=doc;
  if(!validCanvasSize(width,height)){toast('导出范围超过支持上限');return;}button.disabled=true;button.textContent='正在准备作品…';
  try{
   await Promise.all(region.layers.filter(layer=>layer.type==='image').map(layer=>getImage(layer.src)||imagePromises.get(layer.src)));await document.fonts.ready;
   if(!button.isConnected||!$('#modal').open||doc!==currentDocument)return;
   const out=document.createElement('canvas');out.width=width;out.height=height;const context=out.getContext('2d');
   if(!transparent){context.fillStyle=doc.background;context.fillRect(0,0,width,height);}context.scale(width/region.w,height/region.h);context.translate(-region.x,-region.y);for(const layer of region.layers)drawLayer(context,layer);
   const blob=await new Promise(resolve=>out.toBlob(resolve,'image/'+format,quality));if(!blob)throw Error('无法生成图片');
   if(!button.isConnected||!$('#modal').open)return;
   download(blob,safeName()+($('#exportArea').value==='selection'?'_所选图层':'')+'.'+(format==='jpeg'?'jpg':format));$('#modal').close();toast('作品已导出，分享你的灵感吧');
  }catch{if(button.isConnected){button.disabled=false;button.innerHTML=icon('download')+'重试导出';toast('导出失败，请检查图片是否完整加载');}}
 };
}
$('#exportButton').onclick=openExportDialog;

$('#helpButton').onclick=()=>showModal('给创作一点小帮助',`<p>选择基础图形后，在画布上拖动绘制；按住 Shift 等比绘制或限定线条角度，Esc 取消。双击文字框即可直接编辑。右侧面板可以精细调整样式，图层面板可以控制前后顺序。</p><div class="shortcut-list">${[['选择工具 / 框选','V / M'],['区域清除 / 背景色填充','R / Delete'],['裁切画布 / 确认','C / Enter'],['全选可编辑元素','⌘ / Ctrl A'],['增减选择 / 追加框选','Shift + 点击 / 框选'],['移动画布 / 临时移动','H / 空格'],['自由画笔','B'],['添加文字','T'],['撤销 / 重做','⌘ / Ctrl Z · Shift Z'],['复制图层','⌘ / Ctrl D'],['调整图层前后 / 置顶置底','⌘ / Ctrl [ / ] · 加 Shift'],['复制 / 粘贴图层','⌘ / Ctrl C / V'],['保存项目','⌘ / Ctrl S'],['移动元素 / 快速移动','方向键 / Shift + 方向键'],['删除选中图层','Delete / Backspace'],['缩放画布','⌘ / Ctrl + 滚轮'],['保持比例缩放','Shift + 拖动角点']].map(([a,b])=>`<span>${a}</span><kbd>${b}</kbd>`).join('')}</div><p style="margin-top:20px">图片可拖入或直接粘贴。自动保存仅限当前浏览器；重要作品记得保存项目文件。</p>`);
try{const saved=localStorage.getItem(STORAGE);if(saved){const parsed=JSON.parse(saved);if(validateDocument(parsed)){doc=parsed;setSelection([doc.layers.find(l=>l.type==='text')?.id]);}}}catch{}
document.fonts.addEventListener('loadingdone',()=>{render();persist();if(!isTyping(document.activeElement))refreshTextInspector();});
refresh();fit();commit();loadFonts();new ResizeObserver(()=>fit()).observe(viewport);
