# 图绎（Figlyph）

无构建依赖的浏览器图片编辑器。入口 `/editor/`（`editor/index.html`）加载 `editor/editor.css` 和 `editor/editor.js`，复用仓库已有字体与风景图片；所有编辑在本机浏览器完成。

## 本地运行

```sh
python3 -m http.server 8000 --bind 127.0.0.1 --directory /workspace/clyfort.github.io
```

在浏览器访问服务器的 `/editor/` 路径。博客首页保持原样。需要使用 HTTP 服务加载 ES 模块。

## 功能

- 图形：选择矩形、圆角矩形、圆形、三角形、直线、块状箭头或线条箭头工具后，在画布按住鼠标拖动确定位置与尺寸；Shift 等比绘制或限定线条角度，Esc 取消。默认黑色空心，可在属性面板启用填充；箭头有块状和「直线 + V 形箭头」两种。支持反向拖动和斜向箭头；填充、渐变、描边、圆角与阴影。
- 自由画笔：颜色、粗细，可作为独立图层移动与缩放。
- 文字：点击添加文字或按 T 后，在画布单击确定位置并开始输入，Esc 可取消放置；清空全部文字（或仅剩空白）并确认后自动删除文本框，支持撤销。在选择工具下双击画布文字框内任意位置即可直接编辑，点击框外或按 Ctrl/⌘+Enter 完成；高度根据实际字形和换行自动计算，角点拖动等比缩放文字；字体、字号、字重、斜体、下划线、删除线、行距、字距、段距、对齐；选中右侧文字内容中的片段可单独设置样式。
- 文字样式记忆：普通“添加文字”沿用最近使用的字体、字号、粗体、斜体、下划线、删除线、颜色、行距、字距、段距和对齐方式，在当前浏览器中刷新后仍保留；大标题、副标题、正文预设明确采用各自的字号和粗体设置，其他样式继续沿用。
- 文字框宽度：新建文字框默认按文字实际宽度自动增长或缩小，显式换行按最长一行决定宽度；更改字体、字号或局部样式会同步更新。手动修改 W 或拖动角点缩放后转为固定宽度并自动换行，可勾选“随文字自动调整宽度”恢复。保存/重开与撤销保留此模式；旧项目中没有宽度模式标记的文字框保留既有尺寸。
- 混合格式编辑：画布上的文字编辑器支持同一段文字中的不同字体、字号、粗体、颜色及装饰，选中或编辑时继续显示原样；支持换行、纯文本粘贴、中文输入及编辑中的撤销与重做。
- 局部文字样式：在画布文字编辑框或右侧文字内容中选中片段后，直接调整字体、字号、颜色、粗体等设置；切换设置时保持选区，并在画布持续高亮该片段；字体和字号控件保持焦点，继续修改时仍只作用于该片段。编辑内容后失焦不会再次清空选区，插入或删除文字会保留未改动字符的局部样式。
- 字体导入：TTF、OTF、WOFF、WOFF2。字体内嵌保存到项目。
- 图片：文件上传、拖放、粘贴，取景裁切、翻转、亮度、对比度与饱和度。导入时保留原始像素宽高；空画布直接匹配原图尺寸，已有作品按需扩展画布并保留原图层，预览缩放不影响导出分辨率。
- 画布取色：点击颜色控件旁的取色器，再单击画布；可为文字（含局部选区）、填充、描边、渐变终点或画布背景取色。按 I 进入取色，Esc 取消。按实际显示像素采样，支持图片、滤镜、缩放和平移，在本机处理。
- 图片替换：在图片属性中选择「替换图片」，仅更换图片来源，保留图层位置、尺寸、旋转、滤镜、翻转和取景。自定义图层名保持不变；支持撤销与重做，锁定图片须先解锁。
- 图片滤镜：选中图片后，在属性面板查看原图、鲜活、柔光、淡雅、电影、黑白、明亮和浓郁 8 个缩略图预览；一键应用后仍可微调亮度、对比度与饱和度。滤镜直接设置这三个数值，重复切换不叠加；「原图」恢复色彩调整，保留裁切、翻转、尺寸和其他外观。支持撤销、重做、项目保存和导出，锁定图片须先解锁。
- 纯色背景去除：选中图片后打开背景处理，选择背景颜色、容差与边缘柔化；默认只处理连接边缘的背景，可切换为全图匹配，并对照原图预览。在本机工作线程中处理，不上传图片；应用后保留布局和滤镜，可撤销、重做和保存。支持最多 1600 万像素的原图，预览使用缩小图，应用处理原始分辨率。
- 图片布局：一键完整放入、铺满画布或恢复原始像素尺寸；保持图像比例并居中，重置旋转和取景，保留滤镜、翻转和其他外观。
- 对象：拖动、角点缩放、旋转、画布对齐；Shift + 拖动角点保持比例。
- 拖动对齐：移动单个或多个元素时，自动吸附到画布及可见图层的边缘和中心，显示对齐辅助线，支持旋转边界。辅助线独立于画布缩放，以固定线宽绘制；拖动结束、失去焦点或指针捕获中断后立即清除。底部「吸附」可开关并记住偏好；Alt 临时关闭，Shift 限定水平或垂直移动。Esc 或触摸取消会还原本次移动、缩放、旋转或画笔，辅助线不会导出。
- 对齐与分布：6 种边缘/中心对齐，单选对齐画布，多选可选择以所选元素或画布为参考。3 个以上可编辑元素可水平或垂直等间距分布，按旋转后的边界计算并固定两端；锁定或隐藏的图层保持原位。
- 整体变换：多选可见且未锁定的图层后，拖动角点等比缩放，或拖动圆点围绕所选范围中心旋转；Shift 将角度吸附到 15°。右侧也可输入百分比与旋转角度。文字、局部字号、描边、圆角、阴影同步缩放，布局关系保持；手动缩放文字转为固定宽度，可恢复自动调宽。支持撤销、重做和 Esc 取消。
- 多选：Ctrl/⌘ + A 选中所有可见且未锁定的元素；M 框选工具可从任意位置拖出选框，默认选中与框接触的元素，也可在工具栏切换为「完全包含」。选择工具也可从空白区域开始框选。Shift + 点击增减选择、Shift + 框选追加选择；所选元素可整体移动、复制、删除。文字输入框内的 Ctrl/⌘ + A 保持原生文字全选行为。
- 系统字体：提供等线、微软雅黑选项，使用设备已安装的字体，未安装时回退到内置思源黑体；Satoshi 主要用于西文。支持自行导入字体文件。
- 图层：按名称或文字内容搜索；在右侧属性面板自定义图层名，修改文字后继续保留。单选或多选可前移、后移、置顶和置底，保留所选图层的相对顺序；支持显示、锁定、复制和删除。撤销与重做最多保留 60 个状态，撤销编辑后保持该图层被选中。
- 画布：自定义尺寸、预设、背景色、缩放和平移。元素面板、画布设置和区域清除面板均提供白色和黑色背景快捷选项。
- 裁切画布：按 C 或点击裁切工具，拖动选区后按 Enter 或属性面板按钮确认；支持 Shift 正方形、精确坐标尺寸与 Esc 取消。只改变画布范围，所有图层同步平移、框外图层仍保存在项目中，可撤销和重做。
- 区域清除：按 R 或点击工具栏「区域清除」，拖出矩形选区，按 Delete/Backspace（或属性面板按钮）填充为当前背景色；支持撤销、重做、项目保存和导出，背景改色时已清除的区域同步更新。V/M 仍选择和删除完整元素，输入文字时 Delete 仍编辑文字。
- 剪贴板：复制/粘贴所选可编辑图层，保留局部文字样式、自定义名称和相关字体；外部图片优先按图片粘贴，外部纯文字直接成为文字图层。输入框和画布文字编辑保持原生粘贴。
- 文件：PNG、JPG、WebP 导出，支持整个画布或仅所选可见图层；所选图层按独立边界裁切，不包含其他图层，可保留透明背景。支持原始、2 倍、半尺寸与自定义输出宽高，自定义时保持原始比例；PNG 无损输出，JPG / WebP 可调质量。自动限制单边 16384 px 和总面积 6400 万像素；JPG 使用画布背景色。`.figlyph` 项目文件保存/打开，兼容旧版 `.shiguang` 文件。
- 自动保存：小项目保留原有浏览器存储方式；图片或字体较大时自动使用本机数据库，刷新后仍可恢复。后台切换时立即保存，保存顺序与提示保持一致；读取失败不会覆盖旧记录。存储被禁用或空间不足会提示，重要作品请另存项目文件。

基础编辑在浏览器本地进行，不会把图片上传到服务器。大图片、内嵌字体和长历史会占用内存；图片单文件上限 15 MB、字体 20 MB、画布单边最大 16384 像素、总面积最大 6400 万像素。导入的动画图片按静态帧绘制。

## 快捷键

`V` 选择、`M` 框选、`H` 平移、`B` 画笔、`T` 文字；空格临时平移；Ctrl/⌘ + 滚轮缩放。
Ctrl/⌘ + Z 撤销、Shift + Z 重做、D 复制图层、S 保存项目；Ctrl/⌘ + [ / ] 后移或前移，另按 Shift 可置底或置顶；方向键微调位置，Shift 加速。

## 开发回归检查

在已安装 Playwright 与 Chromium 的环境中，启动 HTTP 服务后运行：

```sh
EDITOR_TEST_URL=http://127.0.0.1:8000/editor/ node editor/tests/regressions.cjs
EDITOR_TEST_URL=http://127.0.0.1:8000/editor/ node editor/tests/shapes.cjs
EDITOR_TEST_URL=http://127.0.0.1:8000/editor/ node editor/tests/shape-style.cjs
EDITOR_TEST_URL=http://127.0.0.1:8000/editor/ node editor/tests/region.cjs
EDITOR_TEST_URL=http://127.0.0.1:8000/editor/ node editor/tests/text-edit.cjs
EDITOR_TEST_URL=http://127.0.0.1:8000/editor/ node editor/tests/text-placement.cjs
EDITOR_TEST_URL=http://127.0.0.1:8000/editor/ node editor/tests/text-style.cjs
EDITOR_TEST_URL=http://127.0.0.1:8000/editor/ node editor/tests/text-range.cjs
EDITOR_TEST_URL=http://127.0.0.1:8000/editor/ node editor/tests/rich-text.cjs
EDITOR_TEST_URL=http://127.0.0.1:8000/editor/ node editor/tests/image-presets.cjs
EDITOR_TEST_URL=http://127.0.0.1:8000/editor/ node editor/tests/layout.cjs
EDITOR_TEST_URL=http://127.0.0.1:8000/editor/ node editor/tests/image-layout-export.cjs
EDITOR_TEST_URL=http://127.0.0.1:8000/editor/ node editor/tests/layer-tools.cjs
EDITOR_TEST_URL=http://127.0.0.1:8000/editor/ node editor/tests/clipboard.cjs
EDITOR_TEST_URL=http://127.0.0.1:8000/editor/ node editor/tests/crop.cjs
EDITOR_TEST_URL=http://127.0.0.1:8000/editor/ node editor/tests/text-auto-width.cjs
EDITOR_TEST_URL=http://127.0.0.1:8000/editor/ node editor/tests/local-only.cjs
EDITOR_TEST_URL=http://127.0.0.1:8000/editor/ node editor/tests/snapping.cjs
EDITOR_TEST_URL=http://127.0.0.1:8000/editor/ node editor/tests/group-transform.cjs
EDITOR_TEST_URL=http://127.0.0.1:8000/editor/ node editor/tests/image-replacement.cjs
EDITOR_TEST_URL=http://127.0.0.1:8000/editor/ node editor/tests/autosave.cjs
EDITOR_TEST_URL=http://127.0.0.1:8000/editor/ node editor/tests/custom-export.cjs
EDITOR_TEST_URL=http://127.0.0.1:8000/editor/ node editor/tests/color-picker.cjs
EDITOR_TEST_URL=http://127.0.0.1:8000/editor/ node editor/tests/guide-rendering.cjs
node editor/tests/remove-color.cjs
EDITOR_TEST_URL=http://127.0.0.1:8000/editor/ node editor/tests/background-removal.cjs
```

可用 `CHROMIUM_PATH` 指定浏览器路径，`EDITOR_SCREENSHOT_DIR` 指定测试截图目录（默认系统临时目录）。检查实际文字像素边界、换行和缩放、两种框选方式、多选操作、原图尺寸导入、导出尺寸和刷新恢复。

运行 `python3 editor/package.py` 可重新生成 `editor/downloads/figlyph.zip`，并同步旧版下载链接。
